# NETSCOUT Africa · Sales Intelligence App

## Files

| File | Purpose | Lines |
|---|---|---|
| `index.html` | App structure & HTML only — no logic, no styles | ~431 |
| `styles.css` | All CSS — variables, layout, components, animations | ~269 |
| `app.js` | All JavaScript — state, navigation, rendering, AI, SFDC import | ~932 |

---

## How to launch

### Option 1 — Local (instant)
1. Keep all 3 files in the **same folder**
2. Double-click `index.html`
3. Opens in your browser — done ✅

### Option 2 — Online (shareable link)
1. Go to **netlify.com/drop**
2. Drag the entire folder onto the page
3. Get a live URL in 10 seconds ✅

---

## How to update

| I want to change… | Edit this file |
|---|---|
| Layout, add a new page/section | `index.html` |
| Colours, fonts, spacing, animations | `styles.css` |
| Logic, data, AI prompts, SFDC import | `app.js` |

---

## Salesforce daily import (2 minutes)

1. **Opportunities** → Printable View → Copy → Excel → Save as `opportunities.csv`
   - Columns: Account Name, Opportunity Name, **Domain**, **Industry**, Stage, Probability (%), Opportunity Status, Last Modified Date, Account Territory, Sales Potential

2. Open any Opportunity → **Products** related list → Copy → Excel → Save as `products.csv`
   - Columns: Opportunity Name, Product Description, Quantity, Sales Price, Total Price

3. Open the app → **☁ Salesforce Import** → drop both files → **⚡ Join & Import**

---

## Key sections in app.js

```
APP STATE          line ~20   — all data, localStorage persistence
NAVIGATION         line ~85   — page routing
DASHBOARD          line ~105  — KPIs, charts, opp list, regions
CONFIG             line ~185  — opportunities, regions, targets, profile
MEETINGS           line ~320  — meeting log, attendee chips
DAILY ACTIONS      line ~390  — AI task generation, action cards
AI STRATEGY        line ~490  — domain-aware strategy generator
SFDC IMPORT        line ~580  — two-file CSV import, auto-join
```

---

## Domain differentiation

| Domain | SFDC value | Buyer | Key product |
|---|---|---|---|
| Security | `Security` | CISO, SOC | Arbor DDoS, Omnis Cyber |
| Service Assurance | `Service Assurance` | NOC Director | nGeniusONE, Omnis Analytics |
| Service Providers | `Service Provider` | CTO, VP Network | nGeniusONE, 5G Mgmt |
| Enterprise | `Enterprise` | CIO, IT Director | nGeniusONE, APM |
