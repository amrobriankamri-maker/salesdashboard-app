/* ═══════════════════════════════════════════════════════
   NETSCOUT Africa · Sales Intelligence
   app.js — All application logic
   ══════════════════════════════════════════════════════ */

// ══════════════════════════════════════════════════════
//  APP STATE  (persisted in localStorage)
// ══════════════════════════════════════════════════════
const DEFAULTS = {
  profile: { name:'Sales Manager', role:'Sales Manager', territory:'North Africa', company:'NETSCOUT' },
  opportunities: [
    { id:1, name:'Maroc Telecom – nGeniusONE',  domain:'Service Providers', region:'Morocco', value:680000, stage:'Proposal Sent',  close:'2025-06', prob:75,  product:'nGeniusONE',      industry:'Service Provider', competitor:'Spirent' },
    { id:2, name:'Telecom Egypt – DDoS Arbor',  domain:'Security',          region:'Egypt',   value:540000, stage:'Negotiation',    close:'2025-05', prob:85,  product:'Arbor DDoS',       industry:'Service Provider', competitor:'Radware' },
    { id:3, name:'Banque Centrale Maroc',        domain:'Enterprise',        region:'Morocco', value:480000, stage:'Qualification',  close:'2025-07', prob:60,  product:'nGeniusONE',       industry:'Enterprise',       competitor:'Viavi' },
    { id:4, name:'Algérie Télécom – SA Upgrade', domain:'Service Assurance', region:'Algeria', value:420000, stage:'Proposal Sent',  close:'2025-08', prob:50,  product:'Omnis Analytics',  industry:'Service Provider', competitor:'EXFO' },
    { id:5, name:'Orange Tunisia – nGeniusONE', domain:'Service Providers', region:'Tunisia', value:310000, stage:'Qualification',  close:'2025-09', prob:40,  product:'nGeniusONE',      industry:'Service Provider', competitor:'Spirent' },
    { id:6, name:'Ooredoo Algeria – Security',   domain:'Security',          region:'Algeria', value:290000, stage:'Prospect',       close:'2025-06', prob:30,  product:'Arbor TMS',        industry:'Service Provider', competitor:'Cloudflare' },
    { id:7, name:"Cairo Int'l Airport – Ent.",   domain:'Enterprise',        region:'Egypt',   value:260000, stage:'Qualification',  close:'2025-10', prob:35,  product:'nGeniusONE Edge',  industry:'Enterprise',       competitor:'Viavi' },
  ],
  regions: [
    { id:1, name:'Morocco', active:true, color:'#00c8ff' },
    { id:2, name:'Egypt',   active:true, color:'#00e5a0' },
    { id:3, name:'Algeria', active:true, color:'#ffc542' },
    { id:4, name:'Tunisia', active:true, color:'#ff6b35' },
  ],
  targets: [
    { domain:'Enterprise',        color:'#00c8ff', target:4700000 },
    { domain:'Service Providers', color:'#00e5a0', target:5000000 },
    { domain:'Security',          color:'#ff6b35', target:4000000 },
    { domain:'Service Assurance', color:'#ffc542', target:3500000 },
  ],
  meetings: [],
  actions: [],
};

function load(key) {
  try { const v = localStorage.getItem('ns_'+key); return v ? JSON.parse(v) : DEFAULTS[key]; } catch(e){ return DEFAULTS[key]; }
}
function save(key, val) {
  try { localStorage.setItem('ns_'+key, JSON.stringify(val)); } catch(e){}
}

let APP = {
  profile:       load('profile'),
  opportunities: load('opportunities'),
  regions:       load('regions'),
  targets:       load('targets'),
  meetings:      load('meetings'),
  actions:       load('actions'),
};

// ── DOMAIN COLORS ──
const DOMAIN_COLORS = {
  'Enterprise':'#00c8ff','Service Providers':'#00e5a0','Security':'#ff6b35','Service Assurance':'#ffc542'
};

// ══════════════════════════════════════════════════════
//  NAVIGATION
// ══════════════════════════════════════════════════════
const TITLES = {
  'dashboard':'Overview','strategy':'AI Strategy','meetings':'Meetings',
  'actions':'Daily Actions','config-opportunities':'Configure · Opportunities',
  'config-regions':'Configure · Regions & Targets','config-profile':'Configure · Profile','sfdc':'Salesforce · Import & Sync'
};

function navigate(page, el) {
  document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  const pageEl = document.getElementById('page-'+page);
  if (pageEl) { pageEl.classList.remove('hidden'); pageEl.classList.add('anim'); setTimeout(()=>pageEl.classList.remove('anim'),400); }
  if (el) el.classList.add('active');
  document.getElementById('topbarTitle').textContent = TITLES[page]||page;
  document.getElementById('topbarCrumb').textContent = '';
  if (page==='dashboard') renderDashboard();
  if (page==='config-opportunities') renderOppTable();
  if (page==='config-regions') renderRegionsConfig();
  if (page==='config-profile') loadProfileForm();
  if (page==='meetings') { populateMeetingOppSelect(); renderMeetList(); }
  if (page==='strategy') populateStrategyRegions();
  if (page==='sfdc') renderSFDCPage();
  if (page==='actions') { document.getElementById('actDateLabel2').textContent = new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'}); if(APP.actions.length) renderActSidebar(); }
}

// ══════════════════════════════════════════════════════
//  DASHBOARD RENDER
// ══════════════════════════════════════════════════════
function renderDashboard() {
  renderExecHeader();
  renderPipelineHealth();
  renderIndustryView();
  renderTopOpportunities();
}

function getPipelineByDomain() {
  // Exclude Closed Lost — only count active pipeline
  const res = {};
  APP.opportunities
    .filter(o => o.stage !== 'Closed Lost' && o.value > 0)
    .forEach(o => {
      const domain = o.domain || 'Other';
      res[domain] = (res[domain] || 0) + o.value;
    });
  return res;
}

function getPipelineActive() {
  return APP.opportunities.filter(o => o.stage !== 'Closed Lost');
}

function renderExecHeader() {
  const active      = APP.opportunities.filter(o => o.stage !== 'Closed Lost');
  const lost        = APP.opportunities.filter(o => o.stage === 'Closed Lost');
  const totalPipe   = active.reduce((s,o) => s+(o.value||0), 0);
  const weightedFcst= active.reduce((s,o) => s+(o.value||0)*(o.prob||0)/100, 0);
  const avgProb     = active.length ? active.reduce((s,o)=>s+(o.prob||0),0)/active.length : 0;

  // Pipeline health buckets
  const atRisk    = active.filter(o=>(o.prob||0)<=30);
  const developing= active.filter(o=>(o.prob||0)>30&&(o.prob||0)<=60);
  const strong    = active.filter(o=>(o.prob||0)>60);
  const atRiskVal = atRisk.reduce((s,o)=>s+(o.value||0),0);

  // Stalled = last modified > 30 days ago
  const today = new Date();
  function daysSince(dateStr) {
    if (!dateStr) return 999;
    const parts = String(dateStr).match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
    if (parts) {
      const [,mm,dd,yy] = parts;
      const yr = yy.length===2?(parseInt(yy)<50?'20':'19')+yy:yy;
      const d = new Date(`${yr}-${mm.padStart(2,'0')}-${dd.padStart(2,'0')}`);
      return Math.floor((today-d)/86400000);
    }
    return 999;
  }
  const stalled     = active.filter(o => daysSince(o.rawDate||o.close) > 30);
  const stalledVal  = stalled.reduce((s,o)=>s+(o.value||0),0);

  // Nearest to close
  const hotDeals    = active.filter(o=>(o.prob||0)>=50).sort((a,b)=>b.prob-a.prob);

  const kpiRow = document.getElementById('kpiRow');
  kpiRow.style.gridTemplateColumns = 'repeat(4,1fr)';
  kpiRow.innerHTML = `

    <!-- Card 1: Total Pipeline -->
    <div class="kpi-card" style="border-top:2px solid var(--accent);grid-row:span 1;cursor:pointer" onclick="drillTotalPipeline()">
      <div class="kpi-domain" style="color:var(--accent)">Total Pipeline</div>
      <div class="kpi-value" style="font-size:26px">$${(totalPipe/1e6).toFixed(2)}M</div>
      <div class="kpi-sub">${active.length} active · ${lost.length} lost/closed</div>
      <div style="margin:10px 0 6px;display:flex;gap:6px">
        <div style="flex:1;text-align:center;background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.15);border-radius:8px;padding:6px 4px">
          <div style="font-size:14px;font-weight:700;color:#ff4444">${atRisk.length}</div>
          <div style="font-size:8px;color:var(--muted)">At Risk</div>
        </div>
        <div style="flex:1;text-align:center;background:rgba(255,197,66,0.08);border:1px solid rgba(255,197,66,0.15);border-radius:8px;padding:6px 4px">
          <div style="font-size:14px;font-weight:700;color:var(--accent4)">${developing.length}</div>
          <div style="font-size:8px;color:var(--muted)">Developing</div>
        </div>
        <div style="flex:1;text-align:center;background:rgba(0,229,160,0.08);border:1px solid rgba(0,229,160,0.15);border-radius:8px;padding:6px 4px">
          <div style="font-size:14px;font-weight:700;color:var(--accent3)">${strong.length}</div>
          <div style="font-size:8px;color:var(--muted)">Strong</div>
        </div>
      </div>
    </div>

    <!-- Card 2: Weighted Forecast -->
    <div class="kpi-card" style="border-top:2px solid var(--accent3);cursor:pointer" onclick="drillForecast()">
      <div class="kpi-domain" style="color:var(--accent3)">Weighted Forecast</div>
      <div class="kpi-value" style="font-size:26px">$${(weightedFcst/1e6).toFixed(2)}M</div>
      <div class="kpi-sub">${Math.round(avgProb)}% avg win probability</div>
      <div class="kpi-bar" style="margin:10px 0 4px"><div class="kpi-bar-fill" style="width:${Math.round(avgProb)}%;background:var(--accent3)"></div></div>
      <div class="kpi-footer">
        <span style="color:var(--muted)">Coverage ratio</span>
        <span style="color:${totalPipe>0?'var(--accent3)':'var(--muted)'}">${totalPipe>0?(weightedFcst/totalPipe*100).toFixed(0)+'%':'—'}</span>
      </div>
    </div>

    <!-- Card 3: Stalled Deals -->
    <div class="kpi-card" style="border-top:2px solid ${stalled.length>0?'#ff6b35':'var(--border)'};cursor:pointer" onclick="drillStalled()">
      <div class="kpi-domain" style="color:${stalled.length>0?'var(--accent2)':'var(--muted)'}">
        ${stalled.length>0?'⚠ Stalled Deals':'Stalled Deals'}
      </div>
      <div class="kpi-value" style="font-size:26px;color:${stalled.length>0?'var(--accent2)':'var(--muted)'}">
        ${stalled.length}
      </div>
      <div class="kpi-sub">No activity &gt;30 days · $${(stalledVal/1e6).toFixed(1)}M at risk</div>
      <div style="margin-top:10px;display:flex;flex-direction:column;gap:4px">
        ${stalled.slice(0,3).map(o=>`
          <div style="display:flex;justify-content:space-between;font-size:9px;padding:3px 0;border-bottom:1px solid rgba(26,47,74,0.4)">
            <span style="color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:130px">${(o.account||o.name||'').slice(0,22)}</span>
            <span style="color:var(--accent2);flex-shrink:0">$${((o.value||0)/1000).toFixed(0)}K</span>
          </div>`).join('')}
        ${stalled.length>3?`<div style="font-size:9px;color:var(--muted)">+${stalled.length-3} more stalled</div>`:''}
      </div>
    </div>

    <!-- Card 4: Hot Deals / Next to Close -->
    <div class="kpi-card" style="border-top:2px solid var(--accent4);cursor:pointer" onclick="drillHotDeals()">
      <div class="kpi-domain" style="color:var(--accent4)">🔥 Hot Deals</div>
      <div class="kpi-value" style="font-size:26px">${hotDeals.length}</div>
      <div class="kpi-sub">Win probability ≥50% · $${(hotDeals.reduce((s,o)=>s+(o.value||0),0)/1e6).toFixed(1)}M</div>
      <div style="margin-top:10px;display:flex;flex-direction:column;gap:4px">
        ${hotDeals.slice(0,3).map(o=>`
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:9px;padding:3px 0;border-bottom:1px solid rgba(26,47,74,0.4)">
            <span style="color:var(--text2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:110px">${(o.account||o.name||'').slice(0,18)}</span>
            <div style="display:flex;gap:5px;align-items:center;flex-shrink:0">
              <span style="color:var(--accent3);font-weight:600">${o.prob}%</span>
              <span style="color:var(--muted)">$${((o.value||0)/1000).toFixed(0)}K</span>
            </div>
          </div>`).join('')}
        ${hotDeals.length===0?`<div style="font-size:10px;color:var(--muted);text-align:center;padding:10px 0">No deals above 50% yet</div>`:''}
      </div>
    </div>`;
}

// ── Pipeline health bar (thin row between KPIs and industry cards) ──
function renderPipelineHealth() {
  const active = APP.opportunities.filter(o => o.stage !== 'Closed Lost' && (o.value||0)>0);
  const total  = active.reduce((s,o)=>s+(o.value||0),0);
  if (!total) return;

  const stages = ['Qualification','Proposal Sent','Negotiation','Closed Won'];
  const STAGE_COLORS = {
    'Qualification':'#00c8ff','Proposal Sent':'#7b2fff',
    'Negotiation':'#ffc542','Closed Won':'#00e5a0',
  };

  const byStage = {};
  active.forEach(o => {
    const s = o.stage||'Other';
    byStage[s] = (byStage[s]||0) + (o.value||0);
  });

  const kpiRow = document.getElementById('kpiRow');
  if (!kpiRow) return;

  // Insert health bar panel after KPI row
  let healthBar = document.getElementById('pipelineHealthBar');
  if (!healthBar) {
    healthBar = document.createElement('div');
    healthBar.id = 'pipelineHealthBar';
    healthBar.style.cssText = 'margin-bottom:20px';
    kpiRow.parentNode.insertBefore(healthBar, kpiRow.nextSibling);
  }

  const segments = [...stages, ...Object.keys(byStage).filter(s=>!stages.includes(s))]
    .filter(s => byStage[s] > 0)
    .map(s => {
      const val = byStage[s]||0;
      const pct = (val/total*100).toFixed(1);
      const color = STAGE_COLORS[s]||'#5a7a99';
      const cnt   = active.filter(o=>o.stage===s).length;
      return { s, val, pct, color, cnt };
    });

  healthBar.innerHTML = `
    <div class="panel" style="padding:16px 20px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <div style="font-family:'Syne',sans-serif;font-size:12px;font-weight:700">Pipeline Funnel</div>
        <div style="display:flex;gap:14px">
          ${segments.map(seg=>`
            <div style="display:flex;align-items:center;gap:5px;font-size:9px">
              <div style="width:8px;height:8px;border-radius:2px;background:${seg.color}"></div>
              <span style="color:var(--text2)">${seg.s}</span>
              <span style="color:var(--muted)">${seg.cnt} · $${(seg.val/1e6).toFixed(1)}M</span>
            </div>`).join('')}
        </div>
      </div>
      <div style="display:flex;height:12px;border-radius:6px;overflow:hidden;gap:2px">
        ${segments.map(seg=>`
          <div style="flex:${seg.pct};background:${seg.color};border-radius:2px;min-width:${seg.pct<3?'4px':'0'};position:relative;transition:flex 0.4s ease;cursor:pointer" title="${seg.s}: $${(seg.val/1000).toFixed(0)}K (${seg.pct}%)" onclick="drillStage('${seg.s}')"></div>
        `).join('')}
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:8px;font-size:9px;color:var(--muted)">
        <span>Early Stage</span>
        <span style="color:var(--text2)">Total: $${(total/1e6).toFixed(2)}M</span>
        <span>Close</span>
      </div>
    </div>`;
}


function getPipelineByDomain() {
  // Exclude Closed Lost — only count active pipeline
  const res = {};
  APP.opportunities
    .filter(o => o.stage !== 'Closed Lost' && o.value > 0)
    .forEach(o => {
      const domain = o.domain || 'Other';
      res[domain] = (res[domain] || 0) + o.value;
    });
  return res;
}

function getPipelineActive() {
  return APP.opportunities.filter(o => o.stage !== 'Closed Lost');
}

function renderKPIs() {
  const active      = APP.opportunities.filter(o => o.stage !== 'Closed Lost');
  const lost        = APP.opportunities.filter(o => o.stage === 'Closed Lost');
  const totalPipeline = active.reduce((s,o) => s + (o.value||0), 0);
  const weightedProb  = active.length
    ? active.reduce((s,o) => s + (o.value||0)*(o.prob||0), 0) / Math.max(totalPipeline, 1)
    : 0;
  const forecastVal   = active.reduce((s,o) => s + (o.value||0)*(o.prob||0)/100, 0);

  const kpiRow = document.getElementById('kpiRow');

  // ── ROW 1: Pipeline summary cards ──────────────────────────────
  // Card 1: Total Active Pipeline
  // Card 2: Weighted Forecast
  // Card 3+: One card per domain present in data
  // Card last: Closed Lost summary

  const byDomain = {};
  active.forEach(o => {
    const d = o.domain || 'Other';
    if (!byDomain[d]) byDomain[d] = { count:0, value:0 };
    byDomain[d].count++;
    byDomain[d].value += (o.value||0);
  });

  const COLOR_MAP = {
    'Enterprise':'#00c8ff','Service Providers':'#00e5a0',
    'Security':'#ff6b35','Service Assurance':'#ffc542',
    'Service Assurance/Security':'#ff9f35','Other':'#5a7a99',
  };

  kpiRow.innerHTML = '';

  // ── Card 1: Total Pipeline ──
  kpiRow.innerHTML += `
    <div class="kpi-card" style="border-top:2px solid var(--accent)">
      <div class="kpi-domain" style="color:var(--accent)">Total Active Pipeline</div>
      <div class="kpi-value">$${(totalPipeline/1e6).toFixed(2)}M</div>
      <div class="kpi-sub">${active.length} active opportunit${active.length!==1?'ies':'y'}</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:100%;background:var(--accent)"></div></div>
      <div class="kpi-footer">
        <span style="color:var(--muted)">${lost.length} closed lost</span>
        <span style="color:var(--accent3)">▲ ${active.length} open</span>
      </div>
    </div>`;

  // ── Card 2: Weighted Forecast ──
  kpiRow.innerHTML += `
    <div class="kpi-card" style="border-top:2px solid var(--accent3)">
      <div class="kpi-domain" style="color:var(--accent3)">Weighted Forecast</div>
      <div class="kpi-value">$${(forecastVal/1e6).toFixed(2)}M</div>
      <div class="kpi-sub">Based on win probability</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:${Math.round(weightedProb)}%;background:var(--accent3)"></div></div>
      <div class="kpi-footer">
        <span style="color:var(--muted)">Avg probability</span>
        <span style="color:var(--accent3)">${Math.round(weightedProb)}%</span>
      </div>
    </div>`;

  // ── Cards 3+: One per domain ──
  const domainEntries = Object.entries(byDomain).sort((a,b) => b[1].value - a[1].value);
  domainEntries.forEach(([domain, data], i) => {
    const color  = COLOR_MAP[domain] || '#5a7a99';
    const target = APP.targets.find(t => t.domain === domain);
    const tgtVal = target ? target.target : 0;
    const pct    = tgtVal > 0 ? Math.min(100, Math.round(data.value/tgtVal*100)) : 0;
    const lostD  = lost.filter(o => o.domain === domain).length;
    kpiRow.innerHTML += `
      <div class="kpi-card" style="border-top:2px solid ${color}">
        <div class="kpi-domain" style="color:${color}">${domain}</div>
        <div class="kpi-value">$${(data.value/1e6).toFixed(2)}M</div>
        <div class="kpi-sub">${data.count} opportunit${data.count!==1?'ies':'y'} · Active</div>
        <div class="kpi-bar"><div class="kpi-bar-fill" style="width:${tgtVal>0?pct:100}%;background:${color}"></div></div>
        <div class="kpi-footer">
          ${tgtVal > 0
            ? `<span>Target: $${(tgtVal/1e6).toFixed(1)}M</span><span style="color:${pct>=70?'var(--accent3)':'var(--accent2)'}">${pct}%</span>`
            : `<span style="color:var(--muted)">${lostD > 0 ? lostD+' lost in this domain' : 'Set target in Config'}</span>`
          }
        </div>
      </div>`;
  });

  // Adjust grid columns to fit actual card count
  const cardCount = 2 + domainEntries.length;
  kpiRow.style.gridTemplateColumns = `repeat(${Math.min(cardCount, 4)}, 1fr)`;
}

// ── renderIndustryView: Industry cards with sub-domain breakdown ──
function renderIndustryView() {
  const active = APP.opportunities.filter(o => o.stage !== 'Closed Lost' && (o.value||0) > 0);

  // ── Build industry → domain → opps tree ──
  const tree = {};
  active.forEach(o => {
    const ind = (o.industry || 'Other').trim();
    const dom = (o.domain   || 'Other').trim();
    if (!tree[ind]) tree[ind] = {};
    if (!tree[ind][dom]) tree[ind][dom] = { count:0, value:0, opps:[] };
    tree[ind][dom].count++;
    tree[ind][dom].value += (o.value||0);
    tree[ind][dom].opps.push(o);
  });

  const IND_COLORS = {
    'Service Provider':'#00e5a0','Enterprise':'#00c8ff',
    'Other':'#5a7a99',
  };
  const DOM_COLORS = {
    'Service Assurance':'#ffc542','Security':'#ff6b35',
    'Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff',
    'Service Providers':'#00e5a0','Other':'#5a7a99',
  };
  const STAGE_COLORS = {
    'Qualification':'#00c8ff','Proposal Sent':'#7b2fff',
    'Negotiation':'#ffc542','Closed Won':'#00e5a0',
  };

  // ── Render into the dash-grid ──
  const dashGrid = document.querySelector('.dash-grid');
  if (!dashGrid) return;

  // Build industry cards HTML
  const industryTotal = active.reduce((s,o)=>s+(o.value||0),0);
  let industryHTML = '';

  Object.entries(tree)
    .sort((a,b) => {
      const sumA = Object.values(a[1]).reduce((s,d)=>s+d.value,0);
      const sumB = Object.values(b[1]).reduce((s,d)=>s+d.value,0);
      return sumB - sumA;
    })
    .forEach(([industry, domains]) => {
      const indTotal = Object.values(domains).reduce((s,d)=>s+d.value,0);
      const indCount = Object.values(domains).reduce((s,d)=>s+d.count,0);
      const indPct   = industryTotal > 0 ? (indTotal/industryTotal*100).toFixed(0) : 0;
      const indColor = IND_COLORS[industry] || '#5a7a99';

      // Stage breakdown for this industry
      const stageBreakdown = {};
      Object.values(domains).forEach(d => {
        d.opps.forEach(o => {
          const st = o.stage || 'Unknown';
          if (!stageBreakdown[st]) stageBreakdown[st] = 0;
          stageBreakdown[st] += (o.value||0);
        });
      });

      // Domain rows
      const domainRows = Object.entries(domains)
        .sort((a,b) => b[1].value - a[1].value)
        .map(([domain, data]) => {
          const domPct = indTotal > 0 ? (data.value/indTotal*100).toFixed(0) : 0;
          const domColor = DOM_COLORS[domain] || '#5a7a99';
          return `
            <div style="margin-bottom:10px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                <div style="display:flex;align-items:center;gap:6px">
                  <div style="width:8px;height:8px;border-radius:2px;background:${domColor};flex-shrink:0"></div>
                  <span style="font-size:10px;color:${domColor};font-weight:500">${domain}</span>
                  <span style="font-size:9px;color:var(--muted)">${data.count} opp${data.count!==1?'s':''}</span>
                </div>
                <span style="font-size:11px;font-weight:600;color:var(--text)">$${(data.value/1e6).toFixed(2)}M</span>
              </div>
              <div style="height:5px;background:var(--surface2);border-radius:3px;overflow:hidden">
                <div style="width:${domPct}%;height:100%;background:${domColor};border-radius:3px;opacity:0.85"></div>
              </div>
            </div>`;
        }).join('');

      // Stage pills
      const stagePills = Object.entries(stageBreakdown)
        .sort((a,b)=>b[1]-a[1])
        .map(([st, val]) => {
          const sc = STAGE_COLORS[st] || '#5a7a99';
          const cnt = Object.values(domains).reduce((s,d)=>s+d.opps.filter(o=>o.stage===st).length,0);
          return `<div style="display:flex;align-items:center;justify-content:space-between;padding:5px 0;border-bottom:1px solid rgba(26,47,74,0.4)">
            <div style="display:flex;align-items:center;gap:6px">
              <div style="width:6px;height:6px;border-radius:50%;background:${sc}"></div>
              <span style="font-size:10px;color:var(--text2)">${st}</span>
              <span style="font-size:9px;color:var(--muted)">${cnt}</span>
            </div>
            <span style="font-size:10px;color:var(--muted)">$${(val/1e6).toFixed(2)}M</span>
          </div>`;
        }).join('');

      industryHTML += `
        <div class="panel" style="border-top:3px solid ${indColor};cursor:pointer" onclick="drillIndustry('${industry}')">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:16px">
            <div>
              <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.14em;color:${indColor};margin-bottom:4px">${industry}</div>
              <div style="font-family:'Syne',sans-serif;font-size:22px;font-weight:800;color:var(--text)">$${(indTotal/1e6).toFixed(2)}M</div>
              <div style="font-size:10px;color:var(--muted);margin-top:2px">${indCount} active opportunit${indCount!==1?'ies':'y'} · ${indPct}% of total</div>
            </div>
            <div style="text-align:center;background:${indColor}15;border:1px solid ${indColor}30;border-radius:10px;padding:8px 14px">
              <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:800;color:${indColor}">${indPct}%</div>
              <div style="font-size:8px;color:var(--muted);margin-top:1px">of pipeline</div>
            </div>
          </div>

          <div style="font-size:8px;text-transform:uppercase;letter-spacing:0.12em;color:var(--muted);margin-bottom:10px;display:flex;align-items:center;gap:6px">
            Sub-domains<span style="flex:1;height:1px;background:var(--border)"></span>
          </div>
          ${domainRows}

          <div style="font-size:8px;text-transform:uppercase;letter-spacing:0.12em;color:var(--muted);margin:12px 0 6px;display:flex;align-items:center;gap:6px">
            By Stage<span style="flex:1;height:1px;background:var(--border)"></span>
          </div>
          ${stagePills}
        </div>`;
    });

  // ── Update dash-grid: industry cards span full width, then region cards ──
  dashGrid.innerHTML = `
    <div style="grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px">
      ${industryHTML}
    </div>`;

  // Always rebuild the region panel fresh
  const rp = document.createElement('div');
  rp.className = 'panel';
  rp.innerHTML = `
    <div class="panel-hd">
      <div class="panel-title">Regional View</div>
      <div class="panel-badge">Active pipeline</div>
    </div>
    <div class="region-grid" id="regionGrid"></div>`;
  dashGrid.appendChild(rp);
  renderRegionCards();
}

function renderTopOpportunities() {
  // Render top opps as a full-width table below the industry view
  const dashGrid = document.querySelector('.dash-grid');
  if (!dashGrid) return;

  const active = APP.opportunities.filter(o=>o.stage!=='Closed Lost').sort((a,b)=>b.value-a.value);
  const lost   = APP.opportunities.filter(o=>o.stage==='Closed Lost').sort((a,b)=>b.value-a.value);
  const sorted = [...active, ...lost].slice(0,10);

  const DOM_COLORS = {
    'Service Assurance':'#ffc542','Security':'#ff6b35',
    'Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff',
    'Service Providers':'#00e5a0','Other':'#5a7a99',
  };
  const IND_COLORS = {'Service Provider':'#00e5a0','Enterprise':'#00c8ff'};
  const STAGE_COLORS = {
    'Qualification':'#00c8ff','Proposal Sent':'#7b2fff',
    'Negotiation':'#ffc542','Closed Won':'#00e5a0','Closed Lost':'#ff4444',
  };

  const rows = sorted.map(o => {
    const isLost   = o.stage === 'Closed Lost';
    const dc       = DOM_COLORS[o.domain]  || '#5a7a99';
    const ic       = IND_COLORS[o.industry]|| '#5a7a99';
    const sc       = STAGE_COLORS[o.stage] || '#5a7a99';
    const pc       = o.prob>=70?'#00e5a0':o.prob>=50?'#ffc542':'#ff6b35';
    const prodShort = o.product ? o.product.split(',')[0].trim().slice(0,22) : '—';
    return `
      <tr style="border-bottom:1px solid rgba(26,47,74,0.4);opacity:${isLost?0.35:1};transition:background 0.15s" onmouseover="this.style.background='rgba(255,255,255,0.02)'" onmouseout="this.style.background=''">
        <td style="padding:10px 12px;max-width:200px">
          <div style="font-size:11px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;${isLost?'text-decoration:line-through;color:var(--muted)':''}">${o.name}</div>
          <div style="font-size:9px;color:var(--muted);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${o.account||''}</div>
        </td>
        <td style="padding:10px 12px">
          <span style="font-size:9px;padding:2px 8px;border-radius:6px;background:${ic}15;border:1px solid ${ic}30;color:${ic};white-space:nowrap">${o.industry||'—'}</span>
        </td>
        <td style="padding:10px 12px">
          <span style="font-size:9px;padding:2px 8px;border-radius:6px;background:${dc}15;border:1px solid ${dc}30;color:${dc};white-space:nowrap">${o.domain||'—'}</span>
        </td>
        <td style="padding:10px 12px;font-size:10px;color:var(--muted);max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${o.product||''}">${prodShort}</td>
        <td style="padding:10px 12px">
          <span style="font-size:9px;padding:2px 8px;border-radius:6px;background:${sc}15;border:1px solid ${sc}30;color:${sc};white-space:nowrap">${o.stage}</span>
        </td>
        <td style="padding:10px 12px;text-align:right">
          <div style="font-family:'Syne',sans-serif;font-size:13px;font-weight:700;color:var(--text)">$${(o.value/1000).toFixed(0)}K</div>
        </td>
        <td style="padding:10px 12px;text-align:center">
          <span style="font-size:10px;padding:2px 8px;border-radius:8px;color:${pc};border:1px solid ${pc}30;background:${pc}10">${o.prob}%</span>
        </td>
      </tr>`;
  }).join('');

  const oppPanel = document.createElement('div');
  oppPanel.className = 'panel';
  oppPanel.style.gridColumn = '1/-1';
  oppPanel.innerHTML = `
    <div class="panel-hd">
      <div class="panel-title">Top Opportunities</div>
      <div class="panel-badge">${active.length} active · ${lost.length} lost</div>
    </div>
    <div style="overflow-x:auto">
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="border-bottom:1px solid var(--border)">
            ${['Opportunity / Account','Industry','Domain','Product','Stage','Value','Win %']
              .map(h=>`<th style="text-align:left;padding:6px 12px 10px;font-size:8px;text-transform:uppercase;letter-spacing:0.12em;color:var(--muted);white-space:nowrap">${h}</th>`)
              .join('')}
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
  dashGrid.appendChild(oppPanel);
}

// Keep renderOppList as alias for backwards compat in meetings etc
function renderOppList() {
  const el = document.getElementById('oppList');
  if (!el) return;
  const active = APP.opportunities.filter(o=>o.stage!=='Closed Lost').sort((a,b)=>b.value-a.value);
  const lost   = APP.opportunities.filter(o=>o.stage==='Closed Lost').sort((a,b)=>b.value-a.value);
  const sorted = [...active, ...lost].slice(0,8);
  el.innerHTML = sorted.map(o => {
    const c = DOMAIN_COLORS[o.domain]||'#5a7a99';
    const pc = o.prob>=70?'#00e5a0':o.prob>=50?'#ffc542':'#ff6b35';
    const prodTag     = o.product    ? `<span style="font-size:8px;padding:1px 6px;border-radius:5px;background:rgba(123,47,255,0.1);border:1px solid rgba(123,47,255,0.25);color:#a07fff;margin-left:4px">${o.product}</span>` : '';
    const compTag     = o.competitor ? `<span style="font-size:8px;padding:1px 6px;border-radius:5px;background:rgba(255,107,53,0.08);border:1px solid rgba(255,107,53,0.2);color:var(--accent2);margin-left:3px">vs ${o.competitor}</span>` : '';
    const industryTag = o.industry   ? `<span style="font-size:8px;padding:1px 6px;border-radius:5px;background:rgba(0,229,160,0.07);border:1px solid rgba(0,229,160,0.2);color:var(--accent3);margin-left:3px">${o.industry}</span>` : '';
    const isLost = o.stage === 'Closed Lost';
    return `<div class="opp-row" style="${isLost?'opacity:0.35':''}">
      <div class="opp-stripe" style="background:${isLost?'#333':c}"></div>
      <div class="opp-info">
        <div class="opp-name" style="${isLost?'text-decoration:line-through;color:var(--muted)':''}">${o.name}</div>
        <div class="opp-meta" style="display:flex;align-items:center;flex-wrap:wrap;gap:2px">${o.domain} · ${o.region}${industryTag}${prodTag}${compTag}${isLost?'<span style="font-size:8px;padding:1px 6px;border-radius:5px;background:rgba(255,68,68,0.08);border:1px solid rgba(255,68,68,0.2);color:#ff4444;margin-left:3px">Lost</span>':''}</div>
      </div>
      <div class="opp-right"><div class="opp-val" style="${isLost?'color:var(--muted)':''}">$${(o.value/1000).toFixed(0)}K</div><div class="opp-close">${o.close}</div></div>
      <div class="prob-pill" style="color:${pc};border-color:${pc};background:${pc}18">${o.prob}%</div>
    </div>`;
  }).join('');
}

function renderRegionCards() {
  // Always (re)create the regionGrid element safely
  let el = document.getElementById('regionGrid');
  if (!el) {
    // Element was wiped — skip silently, renderIndustryView will create it
    return;
  }
  const activeOpps = APP.opportunities.filter(o => o.stage !== 'Closed Lost');
  const activeRegs = APP.regions.filter(r => r.active);

  // Also pull any regions that appear in opp data but aren't configured
  const dataRegions = [...new Set(activeOpps.map(o => o.region).filter(Boolean))];
  const allRegionNames = [...new Set([...activeRegs.map(r=>r.name), ...dataRegions])];

  const maxT = Math.max(...allRegionNames.map(
    rn => activeOpps.filter(o=>o.region===rn).reduce((s,o)=>s+(o.value||0),0)
  ), 1);

  el.innerHTML = allRegionNames
    .map(rn => {
      const cfg   = activeRegs.find(r => r.name === rn);
      const color = cfg ? cfg.color : '#5a7a99';
      const total = activeOpps.filter(o=>o.region===rn).reduce((s,o)=>s+(o.value||0),0);
      const opps  = activeOpps.filter(o=>o.region===rn).length;
      const pct   = (total/maxT*100).toFixed(0);
      return `<div class="region-card" style="border-bottom:2px solid ${color}40">
        <div class="region-name" style="color:${color}">${rn}</div>
        <div class="region-val">$${(total/1e6).toFixed(2)}M</div>
        <div class="region-opps">${opps} opportunit${opps!==1?'ies':'y'}</div>
        <div class="region-bar2"><div class="region-bar2-fill" style="width:${pct}%;background:${color}"></div></div>
      </div>`;
    })
    .filter(Boolean)
    .join('');
}

// ══════════════════════════════════════════════════════
//  CONFIG: OPPORTUNITIES
// ══════════════════════════════════════════════════════
function renderOppTable() {
  const tbody = document.getElementById('oppTableBody');
  const stages = ['Prospect','Qualification','Proposal Sent','Negotiation','Closed Won','Closed Lost'];
  tbody.innerHTML = APP.opportunities.map((o,i) => `
    <tr data-id="${o.id}">
      <td><input class="cfg-input" value="${o.name}" onchange="APP.opportunities[${i}].name=this.value" style="width:200px"></td>
      <td><select class="cfg-select" onchange="APP.opportunities[${i}].domain=this.value" style="width:140px">
        ${['Enterprise','Service Providers','Security','Service Assurance'].map(d=>`<option ${o.domain===d?'selected':''}>${d}</option>`).join('')}
      </select></td>
      <td><select class="cfg-select" onchange="APP.opportunities[${i}].region=this.value" style="width:100px">
        ${APP.regions.map(r=>`<option ${o.region===r.name?'selected':''}>${r.name}</option>`).join('')}
      </select></td>
      <td><input class="cfg-input" type="number" value="${o.value}" onchange="APP.opportunities[${i}].value=+this.value" style="width:90px"></td>
      <td><select class="cfg-select" onchange="APP.opportunities[${i}].stage=this.value" style="width:130px">
        ${stages.map(s=>`<option ${o.stage===s?'selected':''}>${s}</option>`).join('')}
      </select></td>
      <td><input class="cfg-input" value="${o.close}" onchange="APP.opportunities[${i}].close=this.value" style="width:90px" placeholder="2025-06"></td>
      <td><input class="cfg-input" type="number" min="0" max="100" value="${o.prob}" onchange="APP.opportunities[${i}].prob=+this.value" style="width:55px"></td>
      <td>
        <input class="cfg-input" value="${o.product||''}" onchange="APP.opportunities[${i}].product=this.value" style="width:130px" placeholder="nGeniusONE, Arbor…" title="${o.product||''}">
        ${o.productLines?.length>1?`<div style="font-size:8px;color:#a07fff;margin-top:2px">${o.productLines.length} SKUs</div>`:''}
      </td>
      <td><input class="cfg-input" value="${o.industry||''}" onchange="APP.opportunities[${i}].industry=this.value" style="width:110px" placeholder="Enterprise, SP…"></td>
      <td><input class="cfg-input" value="${o.competitor||''}" onchange="APP.opportunities[${i}].competitor=this.value" style="width:110px" placeholder="Spirent, Viavi…"></td>
      <td><button class="cfg-btn danger" onclick="deleteOpp(${o.id})">✕</button></td>
    </tr>`).join('');
}

function addOppRow() {
  const newId = Date.now();
  APP.opportunities.push({ id:newId, name:'New Opportunity', domain:'Enterprise', region: APP.regions[0]?.name||'Morocco', value:100000, stage:'Prospect', close:'2025-12', prob:20, product:'', competitor:'' });
  renderOppTable();
  document.getElementById('oppTableBody').lastElementChild?.scrollIntoView({behavior:'smooth'});
}

function deleteOpp(id) {
  APP.opportunities = APP.opportunities.filter(o=>o.id!==id);
  renderOppTable();
}

function saveOpportunities() {
  save('opportunities', APP.opportunities);
  const t = document.getElementById('oppSavedToast');
  t.style.opacity='1'; setTimeout(()=>t.style.opacity='0',2500);
}

// ══════════════════════════════════════════════════════
//  CONFIG: REGIONS & TARGETS
// ══════════════════════════════════════════════════════
function renderRegionsConfig() {
  // Region toggles
  const grid = document.getElementById('regionsGrid');
  grid.innerHTML = APP.regions.map((r,i) => `
    <div style="background:var(--surface2);border:1px solid ${r.active?r.color+'40':'var(--border)'};border-radius:10px;padding:14px;transition:border-color 0.2s">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <div style="font-family:'Syne',sans-serif;font-size:12px;font-weight:700;color:${r.color}">${r.name}</div>
        <label class="toggle"><input type="checkbox" ${r.active?'checked':''} onchange="APP.regions[${i}].active=this.checked;renderRegionsConfig()"><div class="toggle-slider"></div></label>
      </div>
      <input class="cfg-input" value="${r.name}" onchange="APP.regions[${i}].name=this.value" placeholder="Region name" style="margin-bottom:6px">
      <div style="display:flex;align-items:center;gap:8px;margin-top:6px">
        <div style="font-size:9px;color:var(--muted)">Color</div>
        <input type="color" value="${r.color}" onchange="APP.regions[${i}].color=this.value;renderRegionsConfig()" style="width:28px;height:22px;border:none;background:transparent;cursor:pointer;border-radius:4px;overflow:hidden">
      </div>
    </div>`).join('');

  // Targets table
  const byDomain = getPipelineByDomain();
  const tbody = document.getElementById('targetsBody');
  tbody.innerHTML = APP.targets.map((t,i) => {
    const pipeline = byDomain[t.domain]||0;
    const pct = Math.min(100,(pipeline/t.target*100)).toFixed(0);
    return `<tr>
      <td><span class="tag-dot" style="background:${t.color}"></span>${t.domain}</td>
      <td><input type="color" value="${t.color}" onchange="APP.targets[${i}].color=this.value" style="width:28px;height:22px;border:none;background:transparent;cursor:pointer;border-radius:4px"></td>
      <td><input class="cfg-input" type="number" value="${t.target}" onchange="APP.targets[${i}].target=+this.value;renderRegionsConfig()" style="width:120px"></td>
      <td style="color:${t.color}">$${(pipeline/1e6).toFixed(2)}M</td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div style="flex:1;height:6px;background:var(--border);border-radius:3px;overflow:hidden;min-width:80px">
            <div style="width:${pct}%;height:100%;background:${t.color};border-radius:3px"></div>
          </div>
          <span style="font-size:10px;color:${+pct>=70?'var(--accent3)':+pct>=40?'var(--accent4)':'var(--accent2)'}">${pct}%</span>
        </div>
      </td>
    </tr>`;
  }).join('');
}

function addRegion() {
  APP.regions.push({ id:Date.now(), name:'New Region', active:true, color:'#7b2fff' });
  renderRegionsConfig();
}

function saveRegionsTargets() {
  save('regions', APP.regions);
  save('targets', APP.targets);
  const t = document.getElementById('regSavedToast');
  t.style.opacity='1'; setTimeout(()=>t.style.opacity='0',2500);
}

// ══════════════════════════════════════════════════════
//  CONFIG: PROFILE
// ══════════════════════════════════════════════════════
function loadProfileForm() {
  document.getElementById('cfgName').value      = APP.profile.name||'';
  document.getElementById('cfgRole').value      = APP.profile.role||'';
  document.getElementById('cfgTerritory').value = APP.profile.territory||'';
  document.getElementById('cfgCompany').value   = APP.profile.company||'';
}

function saveProfile() {
  APP.profile.name      = document.getElementById('cfgName').value;
  APP.profile.role      = document.getElementById('cfgRole').value;
  APP.profile.territory = document.getElementById('cfgTerritory').value;
  APP.profile.company   = document.getElementById('cfgCompany').value;
  save('profile', APP.profile);
  applyProfile();
  const t = document.getElementById('profileSavedToast');
  t.style.opacity='1'; setTimeout(()=>t.style.opacity='0',2500);
}

function applyProfile() {
  const p = APP.profile;
  document.getElementById('userNameDisplay').textContent = p.name||'Sales Manager';
  document.getElementById('userRoleDisplay').textContent = p.territory||'North Africa';
  const initials = (p.name||'SM').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  document.getElementById('userInitials').textContent = initials;
}

// ══════════════════════════════════════════════════════
//  MEETINGS
// ══════════════════════════════════════════════════════
let attendees2 = [];

function populateMeetingOppSelect() {
  const sel = document.getElementById('mfOpp');
  sel.innerHTML = APP.opportunities.map(o=>`<option>${o.name}</option>`).join('');
  document.getElementById('mfDate').value = new Date().toISOString().split('T')[0];
}

document.getElementById('attendeeInput2').addEventListener('keydown', e => {
  if ((e.key==='Enter'||e.key===',') && e.target.value.trim()) {
    e.preventDefault(); attendees2.push(e.target.value.trim()); e.target.value=''; renderChips2();
  }
  if (e.key==='Backspace' && !e.target.value && attendees2.length) { attendees2.pop(); renderChips2(); }
});

function renderChips2() {
  const wrap = document.getElementById('attendeesWrap2');
  const inp  = document.getElementById('attendeeInput2');
  wrap.innerHTML = '';
  attendees2.forEach((a,i) => {
    const c = document.createElement('div');
    c.style.cssText='display:flex;align-items:center;gap:5px;background:rgba(0,102,255,0.12);border:1px solid rgba(0,102,255,0.25);color:#00c8ff;border-radius:20px;padding:2px 9px;font-size:10px';
    c.innerHTML=`${a}<span style="cursor:pointer;opacity:0.6" onclick="attendees2.splice(${i},1);renderChips2()">×</span>`;
    wrap.appendChild(c);
  });
  wrap.appendChild(inp); inp.focus();
}

function saveMeeting() {
  const notes = document.getElementById('mfNotes').value.trim();
  if (!notes) { showMsg('Please add discussion points.'); return; }
  const m = {
    id: Date.now(),
    opp:       document.getElementById('mfOpp').value,
    date:      document.getElementById('mfDate').value,
    type:      document.getElementById('mfType').value,
    sentiment: document.getElementById('mfSentiment').value,
    attendees: [...attendees2],
    notes, actions: document.getElementById('mfActions').value.trim()
  };
  APP.meetings.unshift(m);
  save('meetings', APP.meetings);
  document.getElementById('mfNotes').value='';
  document.getElementById('mfActions').value='';
  attendees2=[]; renderChips2();
  const msg=document.getElementById('meetSavedMsg2');
  msg.textContent='✓ Logged'; setTimeout(()=>msg.textContent='',2000);
  renderMeetList();
}

const SS2={positive:{c:'#00e5a0',l:'😊 Positive'},neutral:{c:'#ffc542',l:'😐 Neutral'},concerned:{c:'#ff9f35',l:'😟 Concerned'},negative:{c:'#ff6b35',l:'🔴 At Risk'}};

function renderMeetList() {
  const el = document.getElementById('meetList2');
  document.getElementById('meetCount2').textContent=`${APP.meetings.length} meeting${APP.meetings.length!==1?'s':''}`;
  if (!APP.meetings.length) {
    el.innerHTML='<div style="text-align:center;padding:30px;color:var(--muted);font-size:11px">No meetings yet</div>'; return;
  }
  el.innerHTML=APP.meetings.map(m=>{
    const ss=SS2[m.sentiment]||SS2.neutral;
    const d=m.date?new Date(m.date+'T12:00').toLocaleDateString('en-GB',{day:'numeric',month:'short'}):'';
    return `<div style="border:1px solid var(--border);border-radius:10px;padding:12px 14px;margin-bottom:8px;background:var(--surface2)">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px">
        <div style="font-family:'Syne',sans-serif;font-size:11px;font-weight:700">${m.opp}</div>
        <div style="font-size:9px;padding:2px 7px;border-radius:8px;border:1px solid ${ss.c}40;color:${ss.c};background:${ss.c}12">${ss.l}</div>
      </div>
      <div style="font-size:10px;color:var(--muted);margin-bottom:5px">${d} · ${m.type}${m.attendees.length?' · '+m.attendees.join(', '):''}</div>
      <div style="font-size:11px;opacity:0.8">${m.notes.length>120?m.notes.slice(0,120)+'…':m.notes}</div>
      <div style="text-align:right;margin-top:6px"><button onclick="APP.meetings=APP.meetings.filter(x=>x.id!==${m.id});save('meetings',APP.meetings);renderMeetList()" style="font-size:9px;color:var(--muted);background:none;border:none;cursor:pointer">🗑 Delete</button></div>
    </div>`;
  }).join('');
}

// ══════════════════════════════════════════════════════
//  DAILY ACTIONS
// ══════════════════════════════════════════════════════
const ATYPE={email:{i:'📧',c:'#00c8ff'},proposal:{i:'📄',c:'#7b2fff'},call:{i:'📞',c:'#00e5a0'},poc:{i:'🧪',c:'#ffc542'},meeting:{i:'🤝',c:'#ff6b35'},followup:{i:'🔁',c:'#5a7a99'},demo:{i:'🖥',c:'#00c8ff'}};
let selActId = null;

async function generateDailyActions() {
  const btn = document.getElementById('genActBtn2');
  btn.disabled=true; btn.textContent='⏳ Generating…';
  document.getElementById('actSidebar2').innerHTML='<div style="text-align:center;padding:40px 10px;color:var(--muted);font-size:11px"><div style="width:28px;height:28px;border:2px solid var(--border);border-top-color:var(--accent4);border-radius:50%;animation:spin 0.9s linear infinite;margin:0 auto 12px"></div>Analysing pipeline…</div>';

  const mCtx = APP.meetings.slice(0,6).map(m=>`${m.opp}|${m.date}|${m.type}|${m.sentiment}|${m.notes.slice(0,150)}`).join('\n')||'No meetings yet';
  const oCtx = APP.opportunities.map(o=>`${o.name}|$${o.value}|${o.domain}|${o.region}|${o.stage}|${o.close}`).join('\n');
  const today = new Date().toISOString().split('T')[0];

  const prompt=`Sales coach for NETSCOUT Africa. Today: ${today}. Rep: ${APP.profile.name} covering ${APP.profile.territory}.
PIPELINE:\n${oCtx}\nMEETINGS:\n${mCtx}
Generate 9-11 daily actions. Include: emails, MoM, proposals, POC use cases, calls, demos.
JSON only: {"actions":[{"id":"a1","type":"email|proposal|call|poc|meeting|followup|demo","title":"max 8 words","opportunity":"name","due":"today|tomorrow|this_week|overdue","priority":"high|medium|low","why":"1 sentence","template":"ready-to-use email/message/MoM/talking points specific to NETSCOUT and account (3-6 sentences)","checklist":["step1","step2","step3"]}]}`;

  try {
    const res=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:1000,messages:[{role:'user',content:prompt}]})});
    const data=await res.json();
    const raw=data.content.map(b=>b.text||'').join('');
    const parsed=JSON.parse(raw.replace(/```json|```/g,'').trim());
    const done=new Set(APP.actions.filter(a=>a.done).map(a=>a.id));
    APP.actions=parsed.actions.map(a=>({...a,done:done.has(a.id)}));
    save('actions',APP.actions);
    renderActSidebar(); updateActionsBadge();
  } catch(e){
    document.getElementById('actSidebar2').innerHTML=`<div style="padding:16px;color:#ff6b35;font-size:11px">⚠ ${e.message}</div>`;
  } finally { btn.disabled=false; btn.textContent='⚡ Regenerate'; }
}

function renderActSidebar() {
  const el=document.getElementById('actSidebar2');
  if (!APP.actions.length){el.innerHTML='<div style="text-align:center;padding:30px;color:var(--muted);font-size:11px">No actions</div>';return;}
  const pending=APP.actions.filter(a=>!a.done);
  el.innerHTML=`<div style="font-size:9px;text-transform:uppercase;letter-spacing:0.12em;color:var(--muted);margin-bottom:10px">${pending.length} pending</div>`+
    APP.actions.map(a=>{
      const t=ATYPE[a.type]||ATYPE.followup;
      const dueC={today:'#ff6b35',tomorrow:'#ffc542',this_week:'#00e5a0',overdue:'#ff4444'}[a.due]||'#5a7a99';
      const dueL={today:'Today',tomorrow:'Tomorrow',this_week:'This Week',overdue:'Overdue'}[a.due]||a.due;
      return `<div onclick="selectAct('${a.id}')" style="border:1px solid ${selActId===a.id?t.c:'var(--border)'};border-radius:10px;padding:10px 12px;margin-bottom:6px;background:${selActId===a.id?t.c+'08':'var(--surface2)'};cursor:pointer;transition:all 0.15s;opacity:${a.done?0.4:1}">
        <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:6px">
          <div style="width:24px;height:24px;border-radius:6px;background:${t.c}18;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">${t.i}</div>
          <div style="flex:1;min-width:0"><div style="font-size:10px;font-weight:500;line-height:1.3;margin-bottom:1px">${a.title}</div><div style="font-size:9px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${a.opportunity}</div></div>
          <div onclick="toggleAct(event,'${a.id}')" style="width:16px;height:16px;border:1.5px solid ${a.done?'var(--accent3)':'var(--border)'};border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;background:${a.done?'var(--accent3)':'transparent'};font-size:9px;color:#000;flex-shrink:0;margin-top:1px">${a.done?'✓':''}</div>
        </div>
        <div style="display:flex;justify-content:space-between">
          <span style="font-size:8px;padding:2px 7px;border-radius:6px;color:${dueC};background:${dueC}18;border:1px solid ${dueC}30">${dueL}</span>
          <span style="font-size:8px;color:var(--muted);text-transform:uppercase">${a.priority}</span>
        </div>
      </div>`;
    }).join('');
}

function selectAct(id) {
  selActId=id;
  const a=APP.actions.find(x=>x.id===id); if(!a) return;
  const t=ATYPE[a.type]||ATYPE.followup;
  renderActSidebar();
  document.getElementById('actDetail2').innerHTML=`
    <div style="padding:4px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px;padding-bottom:16px;border-bottom:1px solid var(--border)">
        <div>
          <div style="display:inline-flex;align-items:center;gap:5px;font-size:9px;padding:3px 10px;border-radius:16px;border:1px solid ${t.c}40;color:${t.c};background:${t.c}10;margin-bottom:7px">${t.i} ${a.type}</div>
          <div style="font-family:'Syne',sans-serif;font-size:16px;font-weight:800;margin-bottom:3px">${a.title}</div>
          <div style="font-size:11px;color:var(--muted)">${a.opportunity}</div>
        </div>
        <button onclick="toggleAct(event,'${a.id}');selectAct('${a.id}')" style="background:${a.done?'var(--surface2)':'var(--accent3)'};color:${a.done?'var(--muted)':'#000'};border:${a.done?'1px solid var(--border)':'none'};border-radius:9px;padding:7px 16px;font-family:'Syne',sans-serif;font-size:11px;font-weight:700;cursor:pointer;white-space:nowrap">${a.done?'↩ Reopen':'✓ Mark Done'}</button>
      </div>
      <div style="margin-bottom:16px">
        <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:7px;display:flex;align-items:center;gap:8px">Why Now<span style="flex:1;height:1px;background:var(--border)"></span></div>
        <div style="font-size:12px;line-height:1.7">${a.why}</div>
      </div>
      <div style="margin-bottom:16px">
        <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:7px;display:flex;align-items:center;gap:8px">Template<span style="flex:1;height:1px;background:var(--border)"></span></div>
        <div style="background:var(--surface2);border:1px solid var(--border);border-left:3px solid var(--accent4);border-radius:0 10px 10px 0;padding:14px 16px;font-size:11px;line-height:1.75;white-space:pre-wrap">${a.template}</div>
        <button onclick="navigator.clipboard.writeText(APP.actions.find(x=>x.id==='${a.id}').template).then(()=>showMsg('Copied!'))" style="margin-top:8px;background:transparent;border:1px solid var(--border);color:var(--muted);border-radius:7px;padding:5px 12px;font-family:'DM Mono',monospace;font-size:9px;cursor:pointer">📋 Copy</button>
      </div>
      <div>
        <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:7px;display:flex;align-items:center;gap:8px">Checklist<span style="flex:1;height:1px;background:var(--border)"></span></div>
        ${(a.checklist||[]).map(s=>`<div style="display:flex;gap:8px;margin-bottom:7px;font-size:11px;line-height:1.4"><div style="width:6px;height:6px;border-radius:50%;background:var(--accent4);flex-shrink:0;margin-top:5px"></div>${s}</div>`).join('')}
      </div>
    </div>`;
}

function toggleAct(e,id) {
  e.stopPropagation();
  const a=APP.actions.find(x=>x.id===id); if(a) a.done=!a.done;
  save('actions',APP.actions);
  renderActSidebar(); updateActionsBadge();
}

function updateActionsBadge() {
  const n=APP.actions.filter(a=>!a.done&&(a.due==='today'||a.due==='overdue')).length;
  const b=document.getElementById('actionsBadge');
  if(n>0){b.textContent=n;b.style.display='flex';}else{b.style.display='none';}
}

// ══════════════════════════════════════════════════════
//  AI STRATEGY (reuse from page)
// ══════════════════════════════════════════════════════
function populateStrategyRegions() {
  const sel=document.getElementById('aiRegion');
  sel.innerHTML=APP.regions.map(r=>`<option>${r.name}</option>`).join('');
}

async function generateStrategy() {
  const opp=document.getElementById('aiOpp').value.trim();
  const acct=document.getElementById('aiAcct').value.trim();
  if(!opp||!acct){showMsg('Fill in Opportunity and Account name.');return;}
  const btn=document.getElementById('aiGenBtn');
  btn.disabled=true; btn.textContent='Generating…';
  const out=document.getElementById('aiOutput');
  out.innerHTML='<div style="display:flex;align-items:center;gap:12px;padding:20px;color:var(--muted);font-size:12px"><div style="width:20px;height:20px;border:2px solid var(--border);border-top-color:#7b2fff;border-radius:50%;animation:spin 0.8s linear infinite"></div>Analysing opportunity…</div>';

  const prompt=`Senior NETSCOUT sales strategist, North Africa specialist.
OPPORTUNITY: ${document.getElementById('aiOpp').value}
ACCOUNT: ${acct}
DOMAIN: ${document.getElementById('aiDomain').value}
REGION: ${document.getElementById('aiRegion').value}
VALUE: ${document.getElementById('aiValue').value||'not specified'}
STAGE: ${document.getElementById('aiStage').value}
CONTEXT: ${document.getElementById('aiContext').value||'none'}
Return ONLY JSON: {"executiveSummary":"","winThemes":["","",""],"risks":["",""],"actionPlan":[{"week":"Week 1-2","action":"","owner":"","priority":"high|medium|low"}],"stakeholders":[{"role":"","concern":"","approach":""}],"competitiveEdge":"","closingProbability":70,"recommendedNextStep":""}`;

  try {
    const res=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:1000,messages:[{role:'user',content:prompt}]})});
    const data=await res.json();
    const s=JSON.parse(data.content.map(b=>b.text||'').join('').replace(/```json|```/g,'').trim());
    const prob=s.closingProbability||60;
    const pc=prob>=70?'#00e5a0':prob>=50?'#ffc542':'#ff6b35';
    const pc_map={high:'#ff6b35',medium:'#ffc542',low:'#00e5a0'};
    out.innerHTML=`<div style="background:var(--surface2);border:1px solid var(--border);border-radius:14px;padding:22px">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px">
        <div><div style="font-family:'Syne',sans-serif;font-size:16px;font-weight:800;margin-bottom:4px">${opp}</div><div style="font-size:11px;color:var(--muted)">${acct}</div></div>
        <div style="text-align:center;border:2px solid ${pc};border-radius:50%;width:60px;height:60px;display:flex;flex-direction:column;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 0 14px ${pc}40">
          <div style="font-family:'Syne',sans-serif;font-size:17px;font-weight:800;color:${pc}">${prob}%</div>
          <div style="font-size:8px;color:var(--muted)">WIN</div>
        </div>
      </div>
      <div style="background:rgba(0,229,160,0.06);border:1px solid rgba(0,229,160,0.2);border-left:3px solid var(--accent3);border-radius:0 9px 9px 0;padding:11px 14px;font-size:12px;color:var(--accent3);margin-bottom:16px">→ ${s.recommendedNextStep}</div>
      <div style="font-size:11px;line-height:1.7;margin-bottom:18px">${s.executiveSummary}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:18px">
        <div><div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:8px">Win Themes</div>${s.winThemes.map(t=>`<div style="font-size:10px;padding:4px 10px;border-radius:8px;background:rgba(0,200,255,0.06);border:1px solid rgba(0,200,255,0.18);color:var(--accent);margin-bottom:5px">${t}</div>`).join('')}</div>
        <div><div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:8px">Risks</div>${s.risks.map(r=>`<div style="font-size:10px;padding:4px 10px;border-radius:8px;background:rgba(255,107,53,0.06);border:1px solid rgba(255,107,53,0.18);color:var(--accent2);margin-bottom:5px">⚠ ${r}</div>`).join('')}</div>
      </div>
      <div style="font-size:9px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:10px">8-Week Action Plan</div>
      ${s.actionPlan.map(a=>`<div style="display:flex;gap:10px;align-items:flex-start;background:var(--surface);border:1px solid var(--border);border-radius:9px;padding:10px 14px;margin-bottom:6px">
        <div style="font-size:9px;color:var(--muted);white-space:nowrap;min-width:70px;padding-top:1px">${a.week}</div>
        <div style="flex:1"><div style="font-size:11px;line-height:1.4;margin-bottom:2px">${a.action}</div><div style="font-size:9px;color:var(--muted)">👤 ${a.owner}</div></div>
        <div style="font-size:8px;text-transform:uppercase;padding:2px 8px;border-radius:8px;color:${pc_map[a.priority]||'#5a7a99'};background:${pc_map[a.priority]||'#5a7a99'}15;border:1px solid ${pc_map[a.priority]||'#5a7a99'}30">${a.priority}</div>
      </div>`).join('')}
      <div style="margin-top:14px;display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <div style="padding:12px 16px;background:rgba(0,200,255,0.05);border:1px solid rgba(0,200,255,0.15);border-radius:9px">
          <div style="font-size:8px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:5px">Target Buyer Persona</div>
          <div style="font-size:11px;color:var(--accent)">👤 ${s.buyerPersona||'—'}</div>
        </div>
        <div style="padding:12px 16px;background:rgba(255,107,53,0.05);border:1px solid rgba(255,107,53,0.15);border-radius:9px">
          <div style="font-size:8px;text-transform:uppercase;letter-spacing:0.13em;color:var(--muted);margin-bottom:5px">Key Pain Point</div>
          <div style="font-size:11px;color:var(--accent2)">⚡ ${s.keyPainPoint||'—'}</div>
        </div>
      </div>
      <div style="margin-top:10px;padding:13px 16px;background:rgba(255,197,66,0.06);border:1px solid rgba(255,197,66,0.2);border-radius:9px;font-size:11px;line-height:1.6">🏆 ${s.competitiveEdge}</div>
    </div>`;
  } catch(e) {
    out.innerHTML=`<div style="color:#ff6b35;font-size:11px;padding:16px">⚠ ${e.message}</div>`;
  } finally { btn.disabled=false; btn.textContent='✦ Generate Strategy'; }
}

// ══════════════════════════════════════════════════════
//  UTILS
// ══════════════════════════════════════════════════════
function showMsg(msg) {
  let t=document.getElementById('globalToast');
  if(!t){t=document.createElement('div');t.id='globalToast';t.style.cssText='position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#0d1624;border:1px solid var(--accent);color:var(--accent);padding:9px 20px;border-radius:20px;font-size:11px;z-index:9999;font-family:DM Mono,monospace;box-shadow:0 4px 20px rgba(0,0,0,0.4)';document.body.appendChild(t);}
  t.textContent=msg;t.style.opacity='1';
  setTimeout(()=>t.style.opacity='0',2500);
}


// ══════════════════════════════════════════════════════
//  SALESFORCE CSV IMPORT — TWO FILE VERSION
// ══════════════════════════════════════════════════════

const DEFAULT_MAPPING = {
  name:       'Opportunity Name',
  account:    'Account Name',
  domain:     'domain',
  industry:   'industry',
  region:     'Account Territory',
  value:      'Sales Potential',
  stage:      'Stage',
  close:      'Last Modified Date',
  prob:       'Probability (%)',
  status:     'Opportunity Status',
  competitor: 'Competitor',
};

let csvMapping     = {...DEFAULT_MAPPING};
let parsedCSVRows  = [];   // opportunities rows
let parsedProdRows = [];   // products rows
let csvHeaders     = [];
let prodHeaders    = [];

function renderSFDCPage() {
  renderFieldMapping();
  const lastSync = localStorage.getItem('ns_last_sync');
  if (lastSync) {
    document.getElementById('lastSyncBar').style.display   = 'flex';
    document.getElementById('lastSyncText').textContent    = 'Last synced: ' + new Date(+lastSync).toLocaleString();
    document.getElementById('lastImportDisplay').textContent = new Date(+lastSync).toLocaleDateString('en-GB',{day:'numeric',month:'short'});
    document.getElementById('sfdcBadge').style.display = 'flex';
  }
}

// ── DRAG & DROP ──────────────────────────────────────
function handleDropOpp(e) {
  e.preventDefault();
  document.getElementById('dropZoneOpp').style.borderColor='var(--border2)';
  document.getElementById('dropZoneOpp').style.background='var(--surface)';
  const file = e.dataTransfer.files[0];
  if (file) loadOppCSV(file); else showMsg('Please drop a CSV file');
}
function handleDropProd(e) {
  e.preventDefault();
  document.getElementById('dropZoneProd').style.borderColor='var(--border2)';
  document.getElementById('dropZoneProd').style.background='var(--surface)';
  const file = e.dataTransfer.files[0];
  if (file) loadProdCSV(file); else showMsg('Please drop a CSV file');
}
function handleFileOpp(input)  { if(input.files[0]) loadOppCSV(input.files[0]); }
function handleFileProd(input) { if(input.files[0]) loadProdCSV(input.files[0]); }

// ── LOAD OPPORTUNITIES CSV ────────────────────────────
function loadOppCSV(file) {
  readCSV(file, (headers, rows) => {
    csvHeaders    = headers;
    parsedCSVRows = rows;
    autoDetectMapping(headers);
    renderFieldMapping(headers);
    const status = document.getElementById('oppFileStatus');
    status.textContent = '✓ ' + rows.length + ' rows loaded';
    status.style.color = 'var(--accent3)';
    document.getElementById('dropZoneOpp').style.borderColor = 'var(--accent3)';
    showMsg('✓ Opportunities file loaded — ' + rows.length + ' rows');
  });
}

// ── LOAD PRODUCTS CSV ─────────────────────────────────
// Expected columns (tab or comma separated):
// Account name | Opportunity name | Product | Product Description |
// Quantity | List Price | Discount | Total Price
function loadProdCSV(file) {
  readCSV(file, (headers, rows) => {
    prodHeaders    = headers;
    parsedProdRows = rows;

    // Find column indexes — case-insensitive, trimmed
    const norm    = s => (s||'').toLowerCase().replace(/\s+/g,' ').trim();
    const hNorm   = headers.map(norm);
    const colIdx  = key => hNorm.findIndex(h => h.includes(key));

    const oppCol   = colIdx('opportunity name');
    const prodCol  = colIdx('product description');  // use description for display
    const skuCol   = colIdx('product');              // product SKU code
    const qtyCol   = colIdx('quantity');
    const listCol  = colIdx('list price');
    const discCol  = colIdx('discount');
    const totalCol = colIdx('total price');

    if (oppCol < 0) {
      showMsg('⚠ Could not find "Opportunity name" column in products file');
      return;
    }

    const summary = {};

    rows.forEach(r => {
      const oppName = (r[oppCol]||'').trim();
      if (!oppName) return;

      const sku         = skuCol  >= 0 ? (r[skuCol]||'').trim()  : '';
      const description = prodCol >= 0 ? (r[prodCol]||'').trim() : sku;
      const qty         = qtyCol  >= 0 ? parseInt(r[qtyCol]||1)  : 1;
      const listPrice   = listCol >= 0 ? parseValue(r[listCol])  : 0;
      const discount    = discCol >= 0 ? parseDiscount(r[discCol]) : 0;
      const totalPrice  = totalCol>= 0 ? parseValue(r[totalCol]) : listPrice * (1 - discount) * qty;

      if (!summary[oppName]) {
        summary[oppName] = {
          skus:         [],
          descriptions: [],
          lines:        [],
          listTotal:    0,
          discTotal:    0,
          netTotal:     0,
        };
      }

      const s = summary[oppName];
      if (sku)         s.skus.push(sku);
      if (description) s.descriptions.push(description);
      s.lines.push({ sku, description, qty, listPrice, discount, totalPrice });
      s.listTotal += listPrice * qty;
      s.discTotal += listPrice * qty * discount;
      s.netTotal  += totalPrice;
    });

    window._productSummary = summary;

    const oppCount  = Object.keys(summary).length;
    const lineCount = rows.length;
    const status    = document.getElementById('prodFileStatus');
    status.textContent = `✓ ${lineCount} lines · ${oppCount} opps`;
    status.style.color = '#a07fff';
    document.getElementById('dropZoneProd').style.borderColor = '#a07fff';

    showMsg(`✓ Products loaded · ${lineCount} line items across ${oppCount} opportunities`);
  });
}

// Parse discount: "45.00%" → 0.45  |  "0.45" → 0.45  |  "45" → 0.45
function parseDiscount(raw) {
  const s = (raw||'').trim().replace('%','');
  const n = parseFloat(s);
  if (isNaN(n)) return 0;
  return n > 1 ? n / 100 : n;
}

// ── READ CSV HELPER ───────────────────────────────────
function readCSV(file, callback) {
  const reader = new FileReader();
  reader.onload = e => {
    const lines = e.target.result.split(/\r?\n/).filter(Boolean);
    if (!lines.length) { showMsg('Empty file'); return; }
    const delim   = lines[0].includes('\t') ? '\t' : ',';
    const headers = parseCSVLine(lines[0], delim);
    const rows    = lines.slice(1).map(l=>parseCSVLine(l,delim)).filter(r=>r.some(Boolean));
    callback(headers, rows);
  };
  reader.readAsText(file);
}

// ── RUN JOIN & IMPORT ─────────────────────────────────
function runImport() {
  if (!parsedCSVRows.length) { showMsg('Please load the Opportunities CSV first'); return; }
  const preview = parsedCSVRows.slice(0,12).map((r,i) => buildOpp(r,i));
  document.getElementById('previewTitle').textContent = `Preview — ${parsedCSVRows.length} opportunities · ${parsedProdRows.length} product lines`;
  document.getElementById('importPreview').style.display = 'block';

  const COLS = ['name','account','domain','region','value','stage','prob','product','totalPrice'];
  const table = document.getElementById('previewTable');
  table.innerHTML = `
    <thead><tr style="border-bottom:1px solid var(--border)">
      ${['Opportunity','Account','Domain','Industry','Territory','Value','Stage','Prob%','Products'].map(c=>`<th style="text-align:left;padding:6px 10px 8px;font-size:8px;text-transform:uppercase;letter-spacing:0.1em;color:var(--muted);white-space:nowrap">${c}</th>`).join('')}
    </tr></thead>
    <tbody>
      ${preview.map(o=>`<tr style="border-bottom:1px solid rgba(26,47,74,0.4)">
        <td style="padding:7px 10px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.name}</td>
        <td style="padding:7px 10px;color:var(--muted);max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.account||'—'}</td>
        <td style="padding:7px 10px"><span style="color:${DOMAIN_COLORS[o.domain]||'#5a7a99'};font-size:10px">${o.domain}</span></td>
        <td style="padding:7px 10px">${o.region}</td>
        <td style="padding:7px 10px;color:var(--accent3)">$${(o.value/1000).toFixed(0)}K</td>
        <td style="padding:7px 10px">${o.stage}</td>
        <td style="padding:7px 10px">${o.prob}%</td>
        <td style="padding:7px 10px;color:#a07fff;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${o.product||''}">${o.product||'—'}</td>
        <td style="padding:7px 10px;color:var(--accent4);white-space:nowrap">${o.totalPrice>0?'$'+(o.totalPrice/1000).toFixed(1)+'K ('+(o.productLines?.length||1)+' lines)':'—'}</td>
      </tr>`).join('')}
      ${parsedCSVRows.length>12?`<tr><td colspan="9" style="padding:8px 10px;color:var(--muted);font-size:10px">… and ${parsedCSVRows.length-12} more rows</td></tr>`:''}
    </tbody>`;
}

// ── BUILD SINGLE OPP WITH JOINED PRODUCTS ────────────
function buildOpp(row, idx) {
  const statusRaw = getCol(row,'status',csvHeaders);
  const name      = getCol(row,'name',csvHeaders) || getCol(row,'account',csvHeaders) || `Opportunity ${idx+1}`;

  // Join products from product table using rich summary
  let product    = getCol(row,'product',csvHeaders);
  let totalPrice = 0;
  let productLines = [];
  if (window._productSummary && window._productSummary[name]) {
    const ps = window._productSummary[name];
    // Use short descriptions for display (truncate long ones)
    if (ps.descriptions.length) {
      product = ps.descriptions
        .map(d => d.split(',')[0].split('(')[0].trim())  // first part before comma or bracket
        .filter((v,i,a) => a.indexOf(v)===i)             // unique
        .join(', ');
    } else if (ps.skus.length) {
      product = ps.skus.join(', ');
    }
    totalPrice   = ps.netTotal;
    productLines = ps.lines;
  }

  // Use Domain field directly, fall back to Industry, then product name
  const domainRaw   = getCol(row,'domain',csvHeaders);
  const industryRaw = getCol(row,'industry',csvHeaders);
  const domain      = mapDomain(domainRaw, industryRaw || product);

  return {
    id:         Date.now() + idx,
    name,
    account:    getCol(row,'account',csvHeaders),
    domain,
    region:     mapRegion(getCol(row,'region',csvHeaders)),
    value:      parseValue(getCol(row,'value',csvHeaders)) || totalPrice,
    stage:      getCol(row,'stage',csvHeaders) || statusRaw || 'Prospect',
    close:      parseDate(getCol(row,'close',csvHeaders)),
    prob:       Math.min(100,Math.max(0,parseInt(getCol(row,'prob',csvHeaders))||50)),
    product,
    productLines,
    industry:   industryRaw,
    competitor: getCol(row,'competitor',csvHeaders),
    status:     statusRaw,
    totalPrice,
  };
}

function confirmImport() {
  const imported = parsedCSVRows.map((r,i)=>buildOpp(r,i)).filter(o=>o.name&&(o.value>0||o.totalPrice>0||o.stage));
  if (!imported.length) { showMsg('No valid rows found — check field mapping'); return; }
  APP.opportunities = enrichRegionFromAccount(imported);
  save('opportunities', APP.opportunities);
  const now = Date.now();
  localStorage.setItem('ns_last_sync', now);
  document.getElementById('importPreview').style.display='none';
  document.getElementById('lastSyncBar').style.display='flex';
  document.getElementById('lastSyncText').textContent='Last synced: just now — '+imported.length+' opportunities';
  document.getElementById('lastImportDisplay').textContent='Today';
  document.getElementById('sfdcBadge').style.display='flex';
  const withProd = imported.filter(o=>o.product).length;
  showMsg('✓ '+imported.length+' opportunities imported · '+withProd+' with products');
}

function clearImport() {
  APP.opportunities = DEFAULTS.opportunities;
  save('opportunities',APP.opportunities);
  localStorage.removeItem('ns_last_sync');
  parsedCSVRows=[]; parsedProdRows=[]; window._productSummary={};
  document.getElementById('lastSyncBar').style.display='none';
  document.getElementById('sfdcBadge').style.display='none';
  document.getElementById('lastImportDisplay').textContent='Never';
  document.getElementById('oppFileStatus').textContent='not loaded';
  document.getElementById('oppFileStatus').style.color='var(--muted)';
  document.getElementById('prodFileStatus').textContent='not loaded';
  document.getElementById('prodFileStatus').style.color='var(--muted)';
  document.getElementById('dropZoneOpp').style.borderColor='var(--border2)';
  document.getElementById('dropZoneProd').style.borderColor='var(--border2)';
  showMsg('Cleared — sample data restored');
}

// ── FIELD MAPPING UI ──────────────────────────────────
function renderFieldMapping(headers) {
  const grid = document.getElementById('fieldMappingGrid');
  const APP_FIELDS = [
    {key:'name',     label:'Opportunity Name',  required:true},
    {key:'account',  label:'Account Name',      required:false},
    {key:'domain',   label:'Domain',            required:true,  hint:'Security / Service Assurance'},
    {key:'industry', label:'Industry',          required:true,  hint:'Enterprise / Service Provider'},
    {key:'region',   label:'Account Territory', required:true},
    {key:'value',    label:'Sales Potential',   required:true},
    {key:'stage',    label:'Stage',             required:true},
    {key:'prob',     label:'Probability (%)',    required:false},
    {key:'status',   label:'Opportunity Status', required:false},
    {key:'close',    label:'Last Modified Date', required:false},
  ];
  grid.innerHTML = APP_FIELDS.map(f => {
    const opts = headers
      ? headers.map(h=>`<option value="${h}" ${csvMapping[f.key]===h?'selected':''}>${h}</option>`).join('')
      : `<option>${csvMapping[f.key]||''}</option>`;
    return `<div class="cfg-field">
      <div class="cfg-label">${f.label}${f.required?' <span style="color:var(--accent2)">*</span>':''} ${f.hint?'<span style="color:var(--muted);font-weight:400;text-transform:none;letter-spacing:0">— '+f.hint+'</span>':''}</div>
      <select class="cfg-select" onchange="csvMapping['${f.key}']=this.value" style="font-size:10px">
        ${headers?'<option value="">— skip —</option>':''}${opts}
      </select>
    </div>`;
  }).join('');
}

// ── HELPERS ───────────────────────────────────────────
function parseCSVLine(line, delim) {
  // Auto-detect delimiter: tab or comma
  if (!delim) {
    delim = line.includes('\t') ? '\t' : ',';
  }
  const result=[]; let cur=''; let inQ=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch==='"'){inQ=!inQ;}
    else if(ch===delim&&!inQ){result.push(cur.trim());cur='';}
    else{cur+=ch;}
  }
  result.push(cur.trim()); return result;
}

function autoDetectMapping(headers) {
  const norm = s => s.toLowerCase().replace(/[^a-z0-9]/g,'');
  const pats = {
    name:     ['opportunityname','opportunity name','name'],
    account:  ['accountname','account name','account','company'],
    domain:   ['domain'],
    industry: ['industry'],
    region:   ['accountterritory','account territory','territory','billingcountry','country','region'],
    value:    ['salespotential','sales potential','amount','value','revenue'],
    stage:    ['stage','stagename'],
    prob:     ['probability (%)','probability','prob'],
    status:   ['opportunitystatus','opportunity status','status'],
    close:    ['lastmodifieddate','last modified date','closedate'],
  };
  headers.forEach(h => {
    const n = norm(h);
    Object.entries(pats).forEach(([key,list]) => {
      if (list.includes(n)) csvMapping[key] = h;
    });
  });
}

function getCol(row, key, headers) {
  const h = headers || csvHeaders;
  const idx = h.indexOf(csvMapping[key]);
  return idx>=0 ? (row[idx]||'').trim() : '';
}

// ── DOMAIN MAP — matches your exact SFDC 'domain' column values ──
const SFDC_DOMAIN_MAP = {
  'service assurance':             'Service Assurance',
  'service assurance & visibility':'Service Assurance',
  'service assurance/security':    'Service Assurance',  // dual-domain — primary is SA
  'security':                      'Security',
  'cyber security':                'Security',
  'cybersecurity':                 'Security',
  'ddos protection':               'Security',
  'enterprise':                    'Enterprise',
  'enterprise networking':         'Enterprise',
  'service provider':              'Service Providers',
  'service providers':             'Service Providers',
  'carrier':                       'Service Providers',
  'telecom':                       'Service Providers',
};

// ── INDUSTRY MAP — matches your exact SFDC 'industry' column values ──
const SFDC_INDUSTRY_MAP = {
  // Your exact SFDC values
  'service provider':          'Service Providers',
  'service providers':         'Service Providers',
  'telecommunications':        'Service Providers',
  'telecom':                   'Service Providers',
  'carrier':                   'Service Providers',
  'enterprise':                'Enterprise',
  'banking':                   'Enterprise',
  'financial services':        'Enterprise',
  'government':                'Enterprise',
  'healthcare':                'Enterprise',
};

// ── STAGE MAP — normalise SFDC stage values ──
const SFDC_STAGE_MAP = {
  // Your exact SFDC stages
  'am verified':               'Qualification',
  'needs analysis':            'Qualification',
  'qualified opportunity':     'Qualification',
  'roi and poc':               'Proposal Sent',
  'value proposition':         'Proposal Sent',
  'id. decision makers':       'Proposal Sent',
  'perception analysis':       'Proposal Sent',
  'proposal/price quote':      'Proposal Sent',
  'netscout selected':         'Negotiation',
  'negotiation/review':        'Negotiation',
  'closed won':                'Closed Won',
  'closed lost':               'Closed Lost',
};

function mapDomain(rawDomain, rawIndustry) {
  // Priority 1: Domain column (lowercase exact match first)
  const d = (rawDomain||'').toLowerCase().trim();
  if (d) {
    if (SFDC_DOMAIN_MAP[d]) return SFDC_DOMAIN_MAP[d];
    for(const [k,v] of Object.entries(SFDC_DOMAIN_MAP)){ if(d.includes(k)) return v; }
  }
  // Priority 2: Industry column
  const ind = (rawIndustry||'').toLowerCase().trim();
  if (ind) {
    if (SFDC_INDUSTRY_MAP[ind]) return SFDC_INDUSTRY_MAP[ind];
    for(const [k,v] of Object.entries(SFDC_INDUSTRY_MAP)){ if(ind.includes(k)) return v; }
  }
  // Priority 3: infer from product
  const PROD_MAP = {
    'ngeniusone':'Service Providers','ngenius':'Service Providers',
    'arbor':'Security','ddos':'Security','omnis cyber':'Security',
    'omnis analytic':'Service Assurance','infinistream':'Service Assurance','ran':'Service Assurance',
  };
  for(const [k,v] of Object.entries(PROD_MAP)){ if(d.includes(k)) return v; }
  return rawDomain || 'Enterprise';
}

function normaliseStage(raw) {
  const r = (raw||'').toLowerCase().trim();
  return SFDC_STAGE_MAP[r] || raw || 'Prospect';
}

function mapRegion(raw) {
  if (!raw) return APP.regions[0]?.name || 'Morocco';
  const r = raw.toLowerCase().trim();

  // Direct country name match
  const known = APP.regions.map(x=>x.name);
  for(const k of known){ if(r.includes(k.toLowerCase())) return k; }

  // Country code / common aliases
  const maps = {
    'ma':'Morocco','morocco':'Morocco',
    'eg':'Egypt','egypt':'Egypt',
    'dz':'Algeria','algeria':'Algeria',
    'tn':'Tunisia','tunisia':'Tunisia',
    'ly':'Libya','libya':'Libya',
    'ml':'Mali','mali':'Mali',
    'sn':'Senegal','senegal':'Senegal',
  };
  if (maps[r]) return maps[r];

  // Team territory codes — infer from common North Africa account patterns
  // Since territory is "Team 4171" (not a country), fall back to first active region
  if (/^team/i.test(raw) || raw === '') {
    return APP.regions.find(r=>r.active)?.name || 'Morocco';
  }

  return raw;
}

// After import, enrich region from account name
function enrichRegionFromAccount(opps) {
  const ACCOUNT_REGION = {
    // Morocco
    'maroc telecom':'Morocco','iam':'Morocco','inwi':'Morocco','orange maroc':'Morocco',
    'al barid bank':'Morocco','ministere':'Morocco','wafa':'Morocco','attijariwafa':'Morocco',
    'banque centrale':'Morocco','sotelma':'Morocco',
    // Algeria
    'djezzy':'Algeria','ooredoo alg':'Algeria','algerie telecom':'Algeria','algérie télécom':'Algeria',
    'mobilis':'Algeria','ooredoo':'Algeria',
    // Tunisia
    'ooredoo tun':'Tunisia','tunisie telecom':'Tunisia','orange tun':'Tunisia',
    'topnet':'Tunisia',
    // Egypt
    'telecom egypt':'Egypt','orange egypt':'Egypt','vodafone egypt':'Egypt','etisalat':'Egypt',
    // Mali/West Africa
    'moov':'Mali','sotelma':'Mali','orange mali':'Mali',
    // Senegal
    'sonatel':'Senegal','orange sn':'Senegal',
  };
  return opps.map(o => {
    if (!o.region || /^team/i.test(o.region)) {
      const acct = (o.account||o.name||'').toLowerCase();
      for (const [key, region] of Object.entries(ACCOUNT_REGION)) {
        if (acct.includes(key)) return {...o, region};
      }
    }
    return o;
  });
}

function parseValue(raw) {
  // Handles: $563,784.38  |  563784  |  $1,200,000.00
  const cleaned = (raw||'').replace(/[$,\s]/g,'').trim();
  const n = parseFloat(cleaned);
  return isNaN(n) ? 0 : n;
}

function parseDate(raw) {
  if (!raw) return '';
  const s = (raw||'').trim();

  // MM/DD/YY or M/D/YY  e.g. 11/19/25 or 2/13/26
  const shortMatch = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2})$/);
  if (shortMatch) {
    const [,mm,dd,yy] = shortMatch;
    const year = parseInt(yy) >= 50 ? '19'+yy : '20'+yy;
    return `${year}-${mm.padStart(2,'0')}`;
  }

  // MM/DD/YYYY
  const longMatch = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (longMatch) {
    const [,mm,dd,yyyy] = longMatch;
    return `${yyyy}-${mm.padStart(2,'0')}`;
  }

  // ISO or other parseable formats
  const d = new Date(s);
  if (!isNaN(d)) return d.toISOString().slice(0,7);

  return s.slice(0,7);
}

// Legacy single-file drop (kept for backwards compat)
function handleDrop(e) { handleDropOpp(e); }
function handleFileInput(input) { handleFileOpp(input); }
function rebuildPreview() {}



// ══════════════════════════════════════════════════════
//  DRILL-DOWN DRAWER
// ══════════════════════════════════════════════════════
function openDrawer(title, sub, bodyHTML) {
  document.getElementById('drawerTitle').textContent = title;
  document.getElementById('drawerSub').textContent   = sub;
  document.getElementById('drawerBody').innerHTML    = bodyHTML;
  document.getElementById('drillDrawer').classList.add('open');
  document.getElementById('drawerOverlay').classList.add('open');
  // Scroll drawer body to top
  document.getElementById('drawerBody').scrollTop = 0;
}

function closeDrawer() {
  document.getElementById('drillDrawer').classList.remove('open');
  document.getElementById('drawerOverlay').classList.remove('open');
}

// Close on Escape key
document.addEventListener('keydown', e => { if(e.key==='Escape') closeDrawer(); });

// ── Drawer content builders ──────────────────────────

function drillTotalPipeline() {
  const active = APP.opportunities.filter(o=>o.stage!=='Closed Lost');
  const total  = active.reduce((s,o)=>s+(o.value||0),0);
  const STAGE_C = {'Qualification':'#00c8ff','Proposal Sent':'#7b2fff','Negotiation':'#ffc542','Closed Won':'#00e5a0'};
  const DOM_C   = {'Service Assurance':'#ffc542','Security':'#ff6b35','Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff','Service Providers':'#00e5a0'};
  const IND_C   = {'Service Provider':'#00e5a0','Enterprise':'#00c8ff'};

  // By Stage
  const byStage = {};
  active.forEach(o=>{ const s=o.stage||'Other'; byStage[s]=(byStage[s]||0)+(o.value||0); });

  // By Domain
  const byDomain = {};
  active.forEach(o=>{ const d=o.domain||'Other'; byDomain[d]=(byDomain[d]||0)+(o.value||0); });

  // By Industry
  const byInd = {};
  active.forEach(o=>{ const i=o.industry||'Other'; byInd[i]=(byInd[i]||0)+(o.value||0); });

  const stageRows = Object.entries(byStage).sort((a,b)=>b[1]-a[1]).map(([s,v])=>{
    const pct=(v/total*100).toFixed(0); const c=STAGE_C[s]||'#5a7a99';
    const cnt=active.filter(o=>o.stage===s).length;
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
        <span style="color:${c}">${s} <span style="color:var(--muted);font-size:9px">(${cnt})</span></span>
        <span>$${(v/1e6).toFixed(2)}M · ${pct}%</span>
      </div>
      <div class="prob-bar-wrap"><div class="prob-bar-fill" style="width:${pct}%;background:${c}"></div></div>
    </div>`;
  }).join('');

  const domRows = Object.entries(byDomain).sort((a,b)=>b[1]-a[1]).map(([d,v])=>{
    const pct=(v/total*100).toFixed(0); const c=DOM_C[d]||'#5a7a99';
    const cnt=active.filter(o=>o.domain===d).length;
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
        <span style="color:${c}">${d} <span style="color:var(--muted);font-size:9px">(${cnt})</span></span>
        <span>$${(v/1e6).toFixed(2)}M · ${pct}%</span>
      </div>
      <div class="prob-bar-wrap"><div class="prob-bar-fill" style="width:${pct}%;background:${c}"></div></div>
    </div>`;
  }).join('');

  const indRows = Object.entries(byInd).sort((a,b)=>b[1]-a[1]).map(([ind,v])=>{
    const pct=(v/total*100).toFixed(0); const c=IND_C[ind]||'#5a7a99';
    const cnt=active.filter(o=>o.industry===ind).length;
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
        <span style="color:${c}">${ind} <span style="color:var(--muted);font-size:9px">(${cnt})</span></span>
        <span>$${(v/1e6).toFixed(2)}M · ${pct}%</span>
      </div>
      <div class="prob-bar-wrap"><div class="prob-bar-fill" style="width:${pct}%;background:${c}"></div></div>
    </div>`;
  }).join('');

  openDrawer('Total Pipeline Breakdown', `$${(total/1e6).toFixed(2)}M across ${active.length} active opportunities`,
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:4px">
       <div class="drawer-stat"><div class="drawer-stat-label">Active Opps</div><div class="drawer-stat-value" style="color:var(--accent)">${active.length}</div></div>
       <div class="drawer-stat"><div class="drawer-stat-label">Total Value</div><div class="drawer-stat-value" style="color:var(--accent)">$${(total/1e6).toFixed(2)}M</div></div>
     </div>
     <div class="drawer-section-title">By Stage</div>${stageRows}
     <div class="drawer-section-title">By Domain</div>${domRows}
     <div class="drawer-section-title">By Industry</div>${indRows}
     ${oppListHTML(active.sort((a,b)=>b.value-a.value).slice(0,15), 'All Active Opportunities')}`
  );
}

function drillForecast() {
  const active   = APP.opportunities.filter(o=>o.stage!=='Closed Lost');
  const forecast = active.reduce((s,o)=>s+(o.value||0)*(o.prob||0)/100,0);
  const buckets  = [
    {label:'🟢 Strong (>60%)',    color:'#00e5a0', opps: active.filter(o=>(o.prob||0)>60)},
    {label:'🟡 Developing (31-60%)', color:'#ffc542', opps: active.filter(o=>(o.prob||0)>30&&(o.prob||0)<=60)},
    {label:'🟠 At Risk (11-30%)', color:'#ff9f35', opps: active.filter(o=>(o.prob||0)>10&&(o.prob||0)<=30)},
    {label:'🔴 Critical (0-10%)',  color:'#ff4444', opps: active.filter(o=>(o.prob||0)<=10)},
  ];

  const bucketHTML = buckets.map(b=>{
    const val = b.opps.reduce((s,o)=>s+(o.value||0)*(o.prob||0)/100,0);
    const pipe = b.opps.reduce((s,o)=>s+(o.value||0),0);
    if (!b.opps.length) return '';
    return `<div class="drawer-stat" style="border-left:3px solid ${b.color}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <span style="font-size:11px;font-weight:600;color:${b.color}">${b.label}</span>
        <span style="font-family:'Syne',sans-serif;font-size:14px;font-weight:800">$${(val/1000).toFixed(0)}K</span>
      </div>
      <div style="font-size:9px;color:var(--muted);margin-bottom:8px">${b.opps.length} opp${b.opps.length!==1?'s':''} · $${(pipe/1e6).toFixed(2)}M pipeline</div>
      ${b.opps.slice(0,3).map(o=>`
        <div style="display:flex;justify-content:space-between;font-size:10px;padding:4px 0;border-top:1px solid rgba(26,47,74,0.4)">
          <span style="color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px">${o.account||o.name}</span>
          <div style="display:flex;gap:8px;flex-shrink:0">
            <span style="color:${b.color}">${o.prob}%</span>
            <span style="color:var(--muted)">$${((o.value||0)/1000).toFixed(0)}K</span>
          </div>
        </div>`).join('')}
      ${b.opps.length>3?`<div style="font-size:9px;color:var(--muted);padding-top:4px">+${b.opps.length-3} more</div>`:''}
    </div>`;
  }).join('');

  openDrawer('Weighted Forecast Detail', `$${(forecast/1e6).toFixed(2)}M forecast · ${active.length} active opportunities`, bucketHTML);
}

function drillStalled() {
  const active = APP.opportunities.filter(o=>o.stage!=='Closed Lost');
  const today  = new Date();

  function daysSince(o) {
    const s = String(o.close||'').trim();
    const m = s.match(/^(\d{4})-(\d{2})$/);
    if (m) { const d=new Date(parseInt(m[1]),parseInt(m[2])-1,1); return Math.floor((today-d)/86400000); }
    const m2 = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/);
    if (m2) { const [,mm,dd,yy]=m2; const yr=yy.length===2?(parseInt(yy)<50?'20':'19')+yy:yy; const d=new Date(parseInt(yr),parseInt(mm)-1,parseInt(dd)); return Math.floor((today-d)/86400000); }
    return 999;
  }

  const withDays = active.map(o=>({...o, days:daysSince(o)})).sort((a,b)=>b.days-a.days);
  const stalled  = withDays.filter(o=>o.days>30);
  const fresh    = withDays.filter(o=>o.days<=30);

  const URGENCY = [
    {label:'🚨 Critical (>90 days)', min:90,   color:'#ff4444'},
    {label:'⚠ High (31-90 days)',    min:31, max:90, color:'#ff6b35'},
  ];

  const rows = (arr, color) => arr.map(o=>{
    const dc = o.days===999?'var(--muted)':o.days>90?'#ff4444':o.days>30?'#ff6b35':'var(--accent3)';
    return `<div class="drawer-opp-row">
      <div style="width:42px;text-align:center;flex-shrink:0">
        <div style="font-size:12px;font-weight:700;color:${dc}">${o.days===999?'?':o.days}</div>
        <div style="font-size:8px;color:var(--muted)">days</div>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:11px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.name}</div>
        <div style="font-size:9px;color:var(--muted);margin-top:1px">${o.account||''} · ${o.stage}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-size:12px;font-weight:600">$${((o.value||0)/1000).toFixed(0)}K</div>
        <div style="font-size:9px;color:var(--muted)">${o.prob}%</div>
      </div>
    </div>`;
  }).join('');

  const stalledVal = stalled.reduce((s,o)=>s+(o.value||0),0);
  openDrawer('⚠ Stalled Deals', `${stalled.length} deals with no activity · $${(stalledVal/1e6).toFixed(2)}M at risk`,
    `<div style="background:rgba(255,107,53,0.06);border:1px solid rgba(255,107,53,0.2);border-radius:10px;padding:12px 16px;margin-bottom:16px;font-size:11px;line-height:1.6;color:var(--text2)">
       These deals have had no recorded activity for over 30 days. Immediate outreach recommended to re-qualify or mark as lost.
     </div>
     <div class="drawer-section-title">Stalled — Needs Action (${stalled.length})</div>
     ${rows(stalled,'#ff6b35')}
     ${fresh.length?`<div class="drawer-section-title">Recently Active (${fresh.length})</div>${rows(fresh,'var(--accent3)')}`:''}
   `);
}

function drillHotDeals() {
  const active   = APP.opportunities.filter(o=>o.stage!=='Closed Lost');
  const hot      = active.filter(o=>(o.prob||0)>=50).sort((a,b)=>b.prob-a.prob);
  const hotVal   = hot.reduce((s,o)=>s+(o.value||0),0);
  const DOM_C    = {'Service Assurance':'#ffc542','Security':'#ff6b35','Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff','Service Providers':'#00e5a0'};

  const rows = hot.map(o=>{
    const pc  = o.prob>=70?'#00e5a0':'#ffc542';
    const dc  = DOM_C[o.domain]||'#5a7a99';
    return `<div class="drawer-opp-row">
      <div style="width:40px;text-align:center;flex-shrink:0">
        <div style="font-size:13px;font-weight:800;color:${pc}">${o.prob}%</div>
        <div style="font-size:8px;color:var(--muted)">win</div>
      </div>
      <div style="flex:1;min-width:0">
        <div style="font-size:11px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.name}</div>
        <div style="font-size:9px;color:var(--muted);margin-top:2px;display:flex;gap:6px;align-items:center">
          <span>${o.account||''}</span>
          <span style="padding:1px 6px;border-radius:4px;background:${dc}15;color:${dc};border:1px solid ${dc}30">${o.domain||''}</span>
        </div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-family:'Syne',sans-serif;font-size:13px;font-weight:700">$${((o.value||0)/1000).toFixed(0)}K</div>
        <div style="font-size:9px;color:var(--muted)">${o.stage}</div>
      </div>
    </div>`;
  }).join('');

  const noHot = `<div style="text-align:center;padding:40px 20px;color:var(--muted)">
    <div style="font-size:32px;opacity:0.2;margin-bottom:10px">🎯</div>
    <div style="font-size:12px;font-weight:600;margin-bottom:6px">No hot deals yet</div>
    <div style="font-size:11px">Deals reach this list when win probability is set to 50% or higher. Update your opportunity probabilities to track momentum.</div>
  </div>`;

  openDrawer('🔥 Hot Deals', `${hot.length} deal${hot.length!==1?'s':''} above 50% · $${(hotVal/1e6).toFixed(2)}M`,
    hot.length ? rows : noHot
  );
}

function drillIndustry(industry) {
  const active  = APP.opportunities.filter(o=>o.stage!=='Closed Lost'&&(o.industry||'Other')===industry);
  const total   = active.reduce((s,o)=>s+(o.value||0),0);
  const DOM_C   = {'Service Assurance':'#ffc542','Security':'#ff6b35','Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff','Service Providers':'#00e5a0'};
  const STAGE_C = {'Qualification':'#00c8ff','Proposal Sent':'#7b2fff','Negotiation':'#ffc542','Closed Won':'#00e5a0'};

  const byDomain = {};
  active.forEach(o=>{ const d=o.domain||'Other'; byDomain[d]=(byDomain[d]||0)+(o.value||0); });

  const domRows = Object.entries(byDomain).sort((a,b)=>b[1]-a[1]).map(([d,v])=>{
    const pct=(v/total*100).toFixed(0); const c=DOM_C[d]||'#5a7a99';
    const cnt=active.filter(o=>o.domain===d).length;
    return `<div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:4px">
        <span style="color:${c}">${d} <span style="color:var(--muted);font-size:9px">(${cnt})</span></span>
        <span>$${(v/1e6).toFixed(2)}M</span>
      </div>
      <div class="prob-bar-wrap"><div class="prob-bar-fill" style="width:${pct}%;background:${c}"></div></div>
    </div>`;
  }).join('');

  openDrawer(industry, `$${(total/1e6).toFixed(2)}M · ${active.length} active opportunities`,
    `<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:4px">
       <div class="drawer-stat"><div class="drawer-stat-label">Pipeline</div><div class="drawer-stat-value" style="color:var(--accent4)">$${(total/1e6).toFixed(2)}M</div></div>
       <div class="drawer-stat"><div class="drawer-stat-label">Forecast</div><div class="drawer-stat-value" style="color:var(--accent3)">$${(active.reduce((s,o)=>s+(o.value||0)*(o.prob||0)/100,0)/1e6).toFixed(2)}M</div></div>
     </div>
     <div class="drawer-section-title">Sub-Domains</div>${domRows}
     ${oppListHTML(active.sort((a,b)=>b.value-a.value), 'All Opportunities')}`
  );
}

function drillStage(stage) {
  const active = APP.opportunities.filter(o=>o.stage===stage);
  const total  = active.reduce((s,o)=>s+(o.value||0),0);
  const STAGE_C= {'Qualification':'#00c8ff','Proposal Sent':'#7b2fff','Negotiation':'#ffc542','Closed Won':'#00e5a0'};
  const color  = STAGE_C[stage]||'#5a7a99';
  openDrawer(stage, `$${(total/1e6).toFixed(2)}M · ${active.length} opportunities`,
    `<div class="drawer-stat" style="border-left:3px solid ${color};margin-bottom:16px">
       <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
         <div><div class="drawer-stat-label">Pipeline</div><div style="font-size:16px;font-weight:700;color:${color}">$${(total/1e6).toFixed(2)}M</div></div>
         <div><div class="drawer-stat-label">Opps</div><div style="font-size:16px;font-weight:700">${active.length}</div></div>
         <div><div class="drawer-stat-label">Avg Win %</div><div style="font-size:16px;font-weight:700">${active.length?Math.round(active.reduce((s,o)=>s+(o.prob||0),0)/active.length):0}%</div></div>
       </div>
     </div>
     ${oppListHTML(active.sort((a,b)=>b.value-a.value), 'Opportunities in this stage')}`
  );
}

// Shared opp list renderer for drawers
function oppListHTML(opps, title) {
  if (!opps.length) return '';
  const DOM_C = {'Service Assurance':'#ffc542','Security':'#ff6b35','Service Assurance/Security':'#ff9f35','Enterprise':'#00c8ff','Service Providers':'#00e5a0'};
  const PC    = p => p>=70?'#00e5a0':p>=50?'#ffc542':'#ff6b35';
  return `<div class="drawer-section-title">${title} (${opps.length})</div>` +
    opps.map(o=>`
      <div class="drawer-opp-row">
        <div style="width:3px;height:36px;border-radius:2px;background:${DOM_C[o.domain]||'#5a7a99'};flex-shrink:0"></div>
        <div style="flex:1;min-width:0">
          <div style="font-size:11px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${o.name}</div>
          <div style="font-size:9px;color:var(--muted);margin-top:1px">${o.account||''} · <span style="color:${DOM_C[o.domain]||'#5a7a99'}">${o.domain||''}</span></div>
        </div>
        <div style="text-align:right;flex-shrink:0">
          <div style="font-size:12px;font-weight:600">$${((o.value||0)/1000).toFixed(0)}K</div>
          <div style="font-size:9px;padding:1px 6px;border-radius:6px;color:${PC(o.prob||0)};border:1px solid ${PC(o.prob||0)}30;background:${PC(o.prob||0)}10;margin-top:2px">${o.prob||0}%</div>
        </div>
      </div>`).join('');
}


// ══════════════════════════════════════════════════════
//  INIT
// ══════════════════════════════════════════════════════
document.getElementById('topbarDate').textContent =
  new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});

applyProfile();
renderDashboard();
if(APP.meetings.length) document.getElementById('meetingsBadge').style.display='flex';
updateActionsBadge();
if(APP.actions.length) renderActSidebar();